<!DOCTYPE html>
<html>
<head>

<title>Network Monitor</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<style>

body{
background:#020617;
color:#22c55e;
font-family:monospace;
}

.log{
animation:fade .4s;
}

@keyframes fade{
from{opacity:0}
to{opacity:1}
}

</style>

</head>

<body>

<div class="flex">

<!-- SIDEBAR -->

<div class="w-64 bg-black h-screen p-6 border-r border-green-700">

<h1 class="text-xl mb-6">CYBER PANEL</h1>

<div class="space-y-3 text-green-400">

<div>Dashboard</div>
<div>Live Logs</div>
<div>Traffic</div>
<div>Devices</div>

</div>

</div>

<!-- MAIN -->

<div class="flex-1 p-6 space-y-6">

<div class="flex justify-between">

<div class="text-xl">Live Network Logs</div>

<div>
Traffic: <span id="traffic">0</span>
</div>

</div>


<!-- GRAPH -->

<div class="bg-black border border-green-700 p-4 rounded">

<canvas id="chart"></canvas>

</div>


<!-- MAP -->

<div class="bg-black border border-green-700 p-4 rounded">

<div class="mb-2 text-sm">Global Connections</div>

<div id="map" style="height:300px"></div>

</div>


<!-- TERMINAL -->

<div class="bg-black border border-green-700 p-4 h-96 overflow-auto rounded" id="terminal"></div>

</div>

</div>

<script>

/* RANDOM HELPER */

function r(a){
return a[Math.floor(Math.random()*a.length)];
}

/* DATA */

const cities=[
"Jakarta","Bandung","Surabaya","Medan","Bekasi",
"Depok","Bogor","Semarang","Makassar","Yogyakarta",
"Malang","Padang","Palembang","Batam"
];

const devices=[
"Samsung Galaxy A14",
"Samsung Galaxy S23",
"Xiaomi Redmi Note 11",
"Xiaomi Redmi Note 12",
"Infinix Hot 30",
"Infinix Note 30",
"iPhone 11",
"iPhone 12",
"iPhone 13",
"Oppo A57",
"Vivo Y36"
];

const browsers=[
"Chrome 120",
"Safari 17",
"Firefox 119"
];

const os=[
"Android 13",
"Android 14",
"iOS 17",
"Windows 11",
"MacOS 14"
];

const isp=[
"Telkomsel",
"Indosat",
"XL Axiata",
"Biznet"
];

const asn=[
"AS7713",
"AS4761",
"AS13335",
"AS15169"
];

const countries=[
["🇮🇩","Indonesia",-6.2,106.8],
["🇺🇸","USA",37.7,-122.4],
["🇸🇬","Singapore",1.35,103.8],
["🇮🇳","India",28.6,77.2]
];

const names1=[
"Rizky","Dimas","Fajar","Kevin","Andika",
"Reza","Arya","Bima","Rama","Bagas"
];

const names2=[
"Pratama","Saputra","Wijaya","Kurniawan",
"Setiawan","Ramadhan","Permana"
];

/* RANDOM GENERATORS */

function randomName(){
return r(names1)+" "+r(names2);
}

function randomEmail(){
return Math.random().toString(36).substring(2,8)+"@gmail.com";
}

function randomPhone(){
return "08"+Math.floor(100000000+Math.random()*900000000);
}

function randomIP(){
return Math.floor(Math.random()*255)+"."+
Math.floor(Math.random()*255)+"."+
Math.floor(Math.random()*255)+"."+
Math.floor(Math.random()*255);
}

function randomPassword(){

let prefix=["Xx","Pro","Mr","Z","Rx",""];
let core=["Shadow","Venom","Ghost","Nova","Dragon","Hunter","Storm"];
let suffix=["YT","OP","X",""];

return r(prefix)+r(core)+Math.floor(Math.random()*999)+r(suffix);

}

/* TERMINAL LOG */

let traffic=0;

function addLog(){

let c=r(countries);

let log=
`[${new Date().toLocaleTimeString()}]

Name: ${randomName()}
Password: ${randomPassword()}
City: ${r(cities)}

Email: ${randomEmail()}
Phone: ${randomPhone()}

Device: ${r(devices)}
Browser: ${r(browsers)}
OS: ${r(os)}

IP: ${randomIP()}
ISP: ${r(isp)}
ASN: ${r(asn)}
Country: ${c[1]}
`;

let div=document.createElement("div");

div.className="log";

div.innerText=log;

document.getElementById("terminal").appendChild(div);

traffic++;

document.getElementById("traffic").innerText=traffic;

document.getElementById("terminal").scrollTop=
document.getElementById("terminal").scrollHeight;


/* MAP MARKER */

L.circleMarker([c[2],c[3]],{
radius:4,
color:"lime"
}).addTo(map);

}

setInterval(addLog,2000);


/* TRAFFIC GRAPH */

let ctx=document.getElementById("chart");

let data=[1,2,3,4,2,5];

let chart=new Chart(ctx,{
type:"line",
data:{
labels:["","","","","",""],
datasets:[{
data:data
}]
},
options:{
plugins:{legend:{display:false}},
scales:{
x:{display:false},
y:{display:false}
}
}
});

setInterval(()=>{
data.push(Math.random()*10);
data.shift();
chart.update();
},2000);


/* MAP */

let map=L.map('map').setView([20,0],2);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

</script>

</body>
</html>