<?php
session_start();

if(!isset($_SESSION['login'])){
header("Location: index.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gmail UI</title>

<style>
body{margin:0;font-family:Arial;background:#f6f8fc}

/* TOPBAR */
.topbar{
    position:fixed;top:0;left:0;width:100%;height:55px;
    background:#fff;border-bottom:1px solid #ddd;
    display:flex;align-items:center;padding:0 15px;z-index:99
}
.menu-icon{font-size:26px;cursor:pointer;margin-right:15px}
.logo{font-size:22px;font-weight:bold;color:#d93025}
#timer{
    font-size:16px;   /* samakan ukuran dengan logo */
    color:#555;
    margin-left:auto; /* dorong ke paling kanan */
}

/* SIDEBAR */
.sidebar{
    position:fixed;top:55px;left:0;width:240px;
    height:calc(100% - 55px);background:#fff;
    border-right:1px solid #ddd;
    transform:translateX(-260px);
    transition:.3s;z-index:90;padding:15px
}
.sidebar.visible{transform:translateX(0)}
.menu-list{list-style:none;padding:0;margin:0}
.menu-list li{
    padding:12px;border-radius:8px;
    cursor:pointer;margin-bottom:6px
}
.menu-list li:hover{background:#f1f3f4}
.menu-list li.active{
    background:#e3e7ff;
    font-weight:bold;
    border-left:4px solid #3558ff
}

/* CONTENT */
.content{padding:80px 20px}
.mail-item{
    background:#fff;padding:12px 15px;
    border-radius:10px;border:1px solid #ddd;
    display:flex;justify-content:space-between;
    margin-bottom:10px;cursor:pointer
}
.mail-item:hover{background:#f1f3f4}
.mail-item.read{background:#eee;color:#777}

/* POPUP */
#popupEmail{
    position:fixed;inset:0;
    background:rgba(0,0,0,.4);
    display:none;align-items:center;justify-content:center;
    z-index:999
}
.popup-box{
    background:transparent;
    width:95%;
    max-width:450px;
    padding:0;
    border-radius:0;
}

.tblResult{width:100%;border-collapse:collapse}
.tblResult th{background:#001240;color:#fff;padding:10px}
.tblResult td{border:2px solid #001240;padding:8px}
.close-btn{
    background:#d93025;color:#fff;
    border:none;padding:8px 15px;
    border-radius:8px;cursor:pointer
}
.mail-item{
    background:#fff;
    padding:10px 15px;
    border-radius:10px;
    border:1px solid #ddd;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:10px;
    cursor:pointer;
    overflow:hidden;
}

.mail-item .left{
    max-width:75%;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.mail-item .right{
    flex-shrink:0;
    font-size:13px;
    color:#666;
}
.sidebar-header{
    text-align:center;
    padding-bottom:15px;
    border-bottom:1px solid #eee;
    margin-bottom:10px;
}
.sidebar-header img{
    width:70px;
    margin-bottom:8px;
}
.sidebar-header a{
    display:inline-block;
    margin-top:6px;
    padding:6px 14px;
    background:#1db954;
    color:#fff;
    border-radius:20px;
    text-decoration:none;
    font-size:12px;
}
.menu-item{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.badge{
    background:#d93025;
    color:#fff;
    font-size:12px;
    padding:2px 8px;
    border-radius:12px;
}
.join-btn{
    display:inline-block;
    margin-top:6px;
    padding:6px 14px;
    background:#1db954; /* hijau */
    color:#fff;
    border-radius:20px;
    text-decoration:none;
    font-size:12px;
}

.join-btn:hover{
    background:#17a44a;
}
.tblResult{
    width:100%;
    border-collapse:separate; /* PENTING */
    border-spacing:0;
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,.15);
}
.wrap{
    word-break: break-all;
    line-height:1.4;
}
/* HEADER DETAIL LOGIN */
.detail-header{
    position:relative;
    background:#0f172a;
    color:#fff;
    padding:12px 42px 12px 12px;
    border-radius:8px 8px 0 0;
    font-size:15px;
    font-weight:bold;
}

/* TOMBOL X */
.close-x{
    position:absolute;
    top:8px;
    right:10px;
    background:transparent;
    border:none;
    color:#fff;
    font-size:20px;
    cursor:pointer;
    line-height:1;
}

.close-x:hover{
    color:#ff4d4d;
}

/* TITLE */
.title{
    display:flex;
    align-items:center;
    gap:8px;
    font-size:19px;
    font-weight:500;
    color:#202124;
    margin-bottom:14px;
}

/* BASE ICON */
.icon{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

/* ===================== */
/* ENVELOPE (SURAT) */
/* ===================== */
.icon.mail{
    border:2px solid #3c4043;
    border-radius:2px;
}

.icon.mail::before{
    content:"";
    position:absolute;
    left:2px;
    right:2px;
    top:5px;
    height:8px;
    border-left:2px solid #3c4043;
    border-right:2px solid #3c4043;
}

.icon.mail::after{
    content:"";
    position:absolute;
    left:2px;
    right:2px;
    top:4px;
    height:2px;
    background:#3c4043;
}

/* ===================== */
/* TRASH (GMAIL STYLE) */
/* ===================== */
.icon.bin{
    border:2px solid #3c4043;
    border-top:none;
    border-radius:0 0 2px 2px;
}

.icon.bin::before{
    content:"";
    position:absolute;
    top:-5px;
    left:-2px;
    width:22px;
    height:2px;
    background:#3c4043;
}

.icon.bin::after{
    content:"";
    position:absolute;
    top:4px;
    left:6px;
    width:2px;
    height:8px;
    background:#3c4043;
    box-shadow:4px 0 0 #3c4043;
}

.left.multi{
    display:flex;
    flex-direction:column;
    gap:3px;
    max-width:75%;
}

.subject{
    font-weight:bold;
    font-size:15px;
    color:#202124;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.subtitle{
    font-size:13px;
    color:#202124;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.preview{
    font-size:12px;
    color:#5f6368;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
.detail-header{
    background:#0f172a;
    color:#fff;
    padding:12px 10px;
    display:grid;
    grid-template-columns:auto 1fr auto;
    align-items:center;
    border-radius:12px 12px 0 0;
}

/* JUDUL TENGAH */
.header-title{
    text-align:center;
    font-size:15px;
    font-weight:bold;
}

/* SIMPAN */
.btn-save{
    background:#22c55e;
    border:none;
    color:#fff;
    padding:6px 12px;
    border-radius:10px;
    font-size:13px;
    cursor:pointer;
}

/* HAPUS */
.btn-delete{
    background:#ef4444;
    border:none;
    color:#fff;
    padding:6px 12px;
    border-radius:10px;
    font-size:13px;
    cursor:pointer;
}

.btn-save:hover{background:#16a34a}
.btn-delete:hover{background:#dc2626}

.avatar{
    width:38px;
    height:38px;
    border-radius:50%;
    background:#d1d5db;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}

.avatar::before{
    content:"";
    width:14px;
    height:14px;
    background:#9ca3af;
    border-radius:50%;
    position:absolute;
    transform:translateY(-6px);
}

.avatar::after{
    content:"";
    width:20px;
    height:10px;
    background:#9ca3af;
    border-radius:10px 10px 0 0;
    position:absolute;
    transform:translateY(8px);
}

.mail-item{
    gap:12px;
}
/* ===================== */
/* PIN / SAVE ICON */
/* ===================== */
.icon.pin{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

.icon.pin::before{
    content:"";
    position:absolute;
    top:0;
    left:4px;
    width:10px;
    height:10px;
    background:#3c4043;
    border-radius:50%;
}

.icon.pin::after{
    content:"";
    position:absolute;
    top:9px;
    left:8px;
    width:2px;
    height:9px;
    background:#3c4043;
    transform:rotate(20deg);
}
/* ===================== */
/* SAVE / SIMPAN (STACK MAIL) */
/* ===================== */
.icon.save{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

/* kotak belakang */
.icon.save::before{
    content:"";
    position:absolute;
    top:3px;
    left:3px;
    width:12px;
    height:10px;
    border:2px solid #3c4043;
    border-radius:2px;
    opacity:.6;
}

/* amplop depan */
.icon.save::after{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:14px;
    height:10px;
    border:2px solid #3c4043;
    border-radius:2px;
    background:#fff;
}

/* garis amplop */
.icon.save span{
    position:absolute;
    top:4px;
    left:2px;
    width:10px;
    height:2px;
    background:#3c4043;
}
/* OVERLAY UNTUK CLOSE SIDEBAR */
.overlay{
    position:fixed;
    top:55px;
    left:0;
    width:100%;
    height:calc(100% - 55px);
    background:transparent;
    z-index:80;
    display:none;
}
.overlay.show{
    display:block;
}
.btn-refresh{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    margin:0 6px;
    cursor:pointer;
    font-size:1em; /* sama ukuran dengan tulisan Gmail */
    transition:0.2s;
}

.btn-refresh:hover{
    transform:rotate(180deg);
}
</style>
</head>

<body>

<!-- TOPBAR -->
<div class="topbar">
    <div class="menu-icon" onclick="toggleSidebar()">☰</div>
    <div class="logo">Gmail<span class="btn-refresh" onclick="refreshInbox()">⟳</span><span id="timer"></span>
    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">

    <!-- LOGO + JOIN -->
    <div class="sidebar-header">
        <img src="assets/logo.png" alt="Logo">

        <div class="reseller">
            <b>Join Reseller</b><br>
            Hubungi Admin<br>
            <a href="javascript:void(0)" class="join-btn" onclick="openLink('https://t.me/apkjasteb')">
    Klik di sini
</a>
        </div>
    </div>

    <!-- MENU -->
    <ul class="menu-list">

        <li class="menu-item" onclick="showInbox(this)">
    <span style="display:flex;align-items:center;gap:10px">
        <div class="icon save"><span></span></div>
        Masuk
    </span>
    <span class="badge" id="inboxCount">99+</span>
        </li>

        <li class="menu-item" onclick="showSaved(this)">
    <span style="display:flex;align-items:center;gap:10px">
        <div class="icon save"><span></span></div>
        Simpan
    </span>
    <span class="badge" id="saveCount">0</span>
</li>

        <hr>

        <li class="menu-item" onclick="openLink('https://t.me/apkjasteb')">
            <span class="menu-text">🔰𝗬𝗼𝘂𝘁𝘂𝗯𝗲</span>
        </li>

        <li class="menu-item" onclick="openLink('https://t.me/apkjasteb')">
            <span class="menu-text">🔰𝗧𝗶𝗸𝘁𝗼𝗸</span>
        </li>

        <li class="menu-item" onclick="openLink('https://t.me/apkjasteb')">
            <span class="menu-text">🔰𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽</span>
        </li>

    </ul>
</div>

<div class="overlay" id="overlay" onclick="closeSidebar()"></div>

<!-- CONTENT -->
<div class="content" id="content"></div>

<!-- POPUP -->
<div id="popupEmail">
    <div class="popup-box">
        <table class="tblResult" id="tblDetail"></table>
    </div>
</div>

<script>
let data = [{"email":"ilahmardotilah0@gmail.com","password":"mamahcantik","login":"Google","ip":"103.191.218.249","extra":["ASN info tidak ditemukan","PT Replay Inti Media","Indonesia","Kuningan","JB","Sunday, 2026-3-15 23:30:45"]},{"email":"subagjariski69@gmail.com","password":"kontol kambing","login":"Google","ip":"140.213.99.84","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Subang","JB","Sunday, 2026-3-15 23:30:32"]},{"email":"2105","password":"dafit firmsnhah","login":"Google","ip":"103.183.58.238","extra":["ASN info tidak ditemukan","PT Core Digital Network","Indonesia","Cianjur","JB","Sunday, 2026-3-15 23:30:02"]},{"email":"augiemllu@gmail.com","password":"KeJu.SuSu","login":"Google","ip":"2001:448a:9070:134f:e0fb:5806:dae7:a40e","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:29:15"]},{"email":"daffa64738@gmail.com","password":"12345678","login":"Google","ip":"202.65.225.19","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:29:05"]},{"email":"202.154.12.249","password":"ASN info tidak ditemukan","login":"AKSESDATA","ip":"Indonesia","extra":["Sempu","JT","Sunday, 2026-3-15 23:27:30"]},{"email":"altanfatur033@gmail.com","password":"sungaicimandiri","login":"Google","ip":"2400:9800:36b:d0e3:4a1b:93b2:1c77:b39f","extra":["ASN info tidak ditemukan","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:26:31"]},{"email":"upinp1586@gmail.com","password":"adalahpokoknya","login":"Google","ip":"114.10.139.176","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Balikpapan","KI","Sunday, 2026-3-15 23:25:20"]},{"email":"Dulguunterbish12@gmail.com","password":"Nmasrai13ge","login":"Google","ip":"2405:5700:302:493b:3201:6957:a8e1:3b0b","extra":["ASN info tidak ditemukan","MCS Com Co Ltd","Mongolia","Ulan Bator","1","Sunday, 2026-3-15 23:25:11"]},{"email":"2222222222","password":"000000","login":"Google","ip":"103.172.0.69","extra":["ASN info tidak ditemukan","PT Cubiespot Pilar Data Nusantara","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 23:25:00"]},{"email":"diazafifrurohman@gmail.com","password":"1233748","login":"Google","ip":"157.85.213.14","extra":["ASN info tidak ditemukan","PT XL Axiata Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:24:56"]},{"email":"ygfvghfugv@gmail.com","password":"KARINNNNNNN","login":"Google","ip":"114.10.121.171","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:24:46"]},{"email":"alvingwanteng@gmail.com","password":"alvin gwanteng","login":"Google","ip":"103.240.68.109","extra":["ASN info tidak ditemukan","PT Parsaoran Global Datatrans","Indonesia","Deli Tua","SU","Sunday, 2026-3-15 23:24:30"]},{"email":"alvingwanteng@gmail.com","password":"alvin gwanteng","login":"Google","ip":"103.240.68.109","extra":["ASN info tidak ditemukan","PT Parsaoran Global Datatrans","Indonesia","Deli Tua","SU","Sunday, 2026-3-15 23:24:30"]},{"email":"muspaidi841@gmail.com","password":"ratnafahri12","login":"Google","ip":"125.163.66.47","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:24:18"]},{"email":"teguhse75@gmail.com","password":"huuh kitu we","login":"Google","ip":"2404:c0:a702:2a7b:dcc3:cf36:19ce:af25","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Bandung","JB","Sunday, 2026-3-15 23:24:08"]},{"email":"em4870422@gmail.com","password":"elmer12345","login":"Google","ip":"2800:cd0:316b:9ebe:4c32:81ff:fe76:d07c","extra":["ASN info tidak ditemukan","Entel S.A. - EntelNet","Bolivia","Santa Cruz de la Sierra","S","Sunday, 2026-3-15 23:23:33"]},{"email":"085178398900","password":"hakim jaa kok","login":"Facebook","ip":"114.125.23.12","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 23:22:47"]},{"email":"085795137695","password":"250581","login":"Facebook","ip":"36.83.117.236","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tasikmalaya","JB","Sunday, 2026-3-15 23:22:35"]},{"email":"178093199","password":"bunya","login":"Google","ip":"2001:d08:2840:f675:189c:f689:c351:8b4","extra":["ASN info tidak ditemukan","Maxis Broadband Sdn Bhd","Malaysia","Kuching","13","Sunday, 2026-3-15 23:22:26"]},{"email":"085352695630","password":"giwa112708","login":"Facebook","ip":"114.10.146.242","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Sunday, 2026-3-15 23:20:11"]},{"email":"kevinajinaraya786@gmail.com","password":"98989887889","login":"Google","ip":"110.138.201.125","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Madiun","JI","Sunday, 2026-3-15 23:20:00"]},{"email":"sitijuraidah786@gmail.com","password":"putra anak mama4444","login":"Google","ip":"202.65.236.9","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:19:58"]},{"email":"awalbayu420@gmail.com","password":"1234awalbayuhabibi","login":"Google","ip":"114.10.135.102","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Makassar","SN","Sunday, 2026-3-15 23:18:54"]},{"email":"rzky24frmnsyh@gmail.com","password":"aqwwwvvccrr12387","login":"Facebook","ip":"119.10.180.254","extra":["ASN info tidak ditemukan","PT. Power Telecom Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:18:34"]},{"email":"cr9997136@gmail.com","password":"b1aw4k","login":"Google","ip":"182.1.44.9","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 23:18:26"]},{"email":"batiarm932@gmail.com","password":"Batiar123","login":"Google","ip":"27.125.247.132","extra":["ASN info tidak ditemukan","UM Public","Malaysia","Bestari Jaya","10","Sunday, 2026-3-15 23:18:09"]},{"email":"lusiastg@gmail.com","password":"Lusiana","login":"Google","ip":"116.254.97.48","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:17:44"]},{"email":"mamahmaulanamaulana6@gmail.com","password":"ajislovedawiyah","login":"Google","ip":"103.68.214.165","extra":["ASN info tidak ditemukan","PT Media Grasi Internet","Indonesia","Sepatan","JB","Sunday, 2026-3-15 23:17:19"]},{"email":"benksetiawan6@gmail.com","password":"EBE.@5nmt@i8cw5","login":"Google","ip":"180.245.73.225","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta Pusat","JK","Sunday, 2026-3-15 23:17:08"]},{"email":"089682121126","password":"Hodijah480@gmailcome","login":"Google","ip":"157.10.184.123","extra":["ASN info tidak ditemukan","PT Internet Tjepat Indonesia","Indonesia","Cikampek","JB","Sunday, 2026-3-15 23:17:06"]},{"email":"bimaabidzar122@gmail.com","password":"aufar2013","login":"Google","ip":"158.140.165.23,168.235.203.215","extra":["ASN info tidak ditemukan","Sunday, 2026-3-15 23:15:52"]},{"email":"082151301535","password":"briva.cantik","login":"Facebook","ip":"125.162.244.63","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:14:13"]},{"email":"103.68.214.165","password":"ASN info tidak ditemukan","login":"PT Media Grasi Internet","ip":"Indonesia","extra":["Sepatan","JB","Sunday, 2026-3-15 23:14:07"]},{"email":"202.58.79.43","password":"ASN info tidak ditemukan","login":"PT Data Buana Nusantara","ip":"Indonesia","extra":["Surabaya","JI","Sunday, 2026-3-15 23:13:47"]},{"email":"tsgshs@gmail.com","password":"dewed","login":"Google","ip":"110.139.127.41","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:13:50"]},{"email":"85971100951","password":"taktauuu","login":"Google","ip":"2404:c0:ba04:d417:6911:6e14:b320:c9f3","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Yogyakarta","YO","Sunday, 2026-3-15 23:13:23"]},{"email":"nataliatorarnataliatorar@gmail.com","password":"14335076018","login":"Google","ip":"36.85.216.76","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Manado","SA","Sunday, 2026-3-15 23:13:11"]},{"email":"handayanijasminerania@gmail.com","password":"Jasmine23","login":"Google","ip":"202.58.79.43","extra":["ASN info tidak ditemukan","PT Data Buana Nusantara","Indonesia","Surabaya","JI","Sunday, 2026-3-15 23:12:32"]},{"email":"083172700014","password":"kiplymbk1221","login":"Facebook","ip":"157.85.210.28","extra":["ASN info tidak ditemukan","PT XLSMART Telecom Sejahtera Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 23:12:07"]},{"email":"supendia98@gmail.com","password":"RAYFAN123@gmil.com","login":"Google","ip":"182.4.72.243","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Padang","SB","Sunday, 2026-3-15 23:11:52"]},{"email":"ike64777@gmail.com","password":"zain zaki kece","login":"Google","ip":"114.8.222.171","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Surabaya","JI","Sunday, 2026-3-15 23:11:47"]},{"email":"awanzulpan@gmail.com","password":"awanajah12","login":"Google","ip":"140.213.147.60","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Banjar Badung","BA","Sunday, 2026-3-15 23:10:36"]},{"email":"fuxigym@gmail.com","password":"RAPLI HERLAMBANG.","login":"Google","ip":"180.245.96.4","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Sukabumi","JB","Sunday, 2026-3-15 23:10:00"]},{"email":"kaffaazmi12@gmail.com","password":"BILAL_123456","login":"Google","ip":"2404:c0:b204:50a9:817c:b873:7f64:6237","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Surabaya","JI","Sunday, 2026-3-15 23:09:38"]},{"email":"attayabilalrayyan@gmail.com","password":"adf","login":"Google","ip":"202.58.74.210","extra":["ASN info tidak ditemukan","PT Data Buana Nusantara","Indonesia","Surabaya","JI","Sunday, 2026-3-15 23:09:25"]},{"email":"sakhaaajikumoro@gmail.com","password":"SaKhAa29113","login":"Google","ip":"182.8.165.10","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Samarinda","KI","Sunday, 2026-3-15 23:09:17"]},{"email":"lonzylonzy0708@gmail.com","password":"ARIPLOLAN2008","login":"Google","ip":"36.85.222.251","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Manado","SA","Sunday, 2026-3-15 23:08:45"]},{"email":"wibuxd85@gmail.com","password":"AKUWIBU.2","login":"Google","ip":"114.122.228.135","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Balikpapan","KI","Sunday, 2026-3-15 23:08:00"]},{"email":"ajapucul@gmail.com","password":"20010","login":"Google","ip":"113.192.12.39","extra":["ASN info tidak ditemukan","PT Parsaoran Global Datatrans","Indonesia","Pangawaren","JT","Sunday, 2026-3-15 23:06:38"]},{"email":"fariseleks127@gmail.com","password":"bidanh","login":"Google","ip":"45.126.248.33","extra":["ASN info tidak ditemukan","PT Reload Media Telematika","Indonesia","Curahklapa","JI","Sunday, 2026-3-15 23:06:38"]},{"email":"082341667408","password":"sinsen dhetan","login":"Facebook","ip":"2a09:bac6:d69c:25cd::3c4:2e","extra":["ASN info tidak ditemukan","Cloudflare, Inc.","Singapore","Singapore","03","Sunday, 2026-3-15 23:05:43"]},{"email":"afrizal10046@gmail.com","password":"AFRIZAL 12344","login":"Google","ip":"2400:9800:541:f74:1:0:2ebc:65c6","extra":["ASN info tidak ditemukan","Indonesia","Palembang","SS","Sunday, 2026-3-15 23:03:30"]},{"email":"Saktimode41@gmail.com","password":"1122222tt","login":"Google","ip":"110.137.81.32","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Payakumbuh","SB","Sunday, 2026-3-15 23:02:09"]},{"email":"nadi12nadi24@gmail.com","password":"rifki123","login":"Google","ip":"125.167.200.168","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Banjarmasin","KS","Sunday, 2026-3-15 23:02:05"]},{"email":"4kbarjaya114@gmail.com","password":"gak tau","login":"Google","ip":"157.20.239.201","extra":["ASN info tidak ditemukan","PT Era Network Indonesia","Indonesia","Gununganyartambak Tengah","JI","Sunday, 2026-3-15 23:02:01"]},{"email":"kluuu32@gmail.com","password":"whooo","login":"Google","ip":"64.235.45.91","extra":["ASN info tidak ditemukan","ServerPoint.com","Singapore","Singapore","01","Sunday, 2026-3-15 23:01:56"]},{"email":"SeptaTriandanil@gmail.com","password":"sandi123","login":"Google","ip":"140.213.65.208","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Palembang","SS","Sunday, 2026-3-15 23:01:37"]},{"email":"daffaliipratama545@gmail.com","password":"123123","login":"Google","ip":"103.191.165.227","extra":["ASN info tidak ditemukan","PT Sakti Wijaya Network","Indonesia","Subang","JB","Sunday, 2026-3-15 22:59:57"]},{"email":"nismawatikabeaken@gmail.com","password":"knpkauambimakunku","login":"Google","ip":"114.122.43.82","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Sunday, 2026-3-15 22:58:58"]},{"email":"matusaim268@gmail.com","password":"dani pribadi","login":"Google","ip":"36.79.124.211","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Indonesia","Indonesia","Surabaya","JI","Sunday, 2026-3-15 22:57:41"]},{"email":"panjialexa821@gmail.com","password":"Muhammad07*","login":"Google","ip":"103.155.156.49","extra":["ASN info tidak ditemukan","Mulkan","Indonesia","Cibatu","JB","Sunday, 2026-3-15 22:57:35"]},{"email":"Pajulan@gmail.com","password":"tghry","login":"Google","ip":"103.155.156.49","extra":["ASN info tidak ditemukan","Mulkan","Indonesia","Cibatu","JB","Sunday, 2026-3-15 22:56:58"]},{"email":"absohabsoh4@gmail.com","password":"absoh","login":"Google","ip":"2404:8000:1003:1ebb:7bd3:ad58:1b29:fd1e","extra":["ASN info tidak ditemukan","BIZNET","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:56:15"]},{"email":"2400:9800:277:d30f:78e3:9c85:7479:da32","password":"ASN info tidak ditemukan","login":"Indonesia","ip":"Bandung","extra":["JB","Sunday, 2026-3-15 22:56:10"]},{"email":"aldoaldo92381@gmail.com","password":"aldojk123","login":"Google","ip":"36.75.105.67","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Denpasar","BA","Sunday, 2026-3-15 22:55:52"]},{"email":"muhsyuhri967@gmail.com","password":"123456sukri","login":"Facebook","ip":"125.167.112.80","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Sunday, 2026-3-15 22:55:11"]},{"email":"ayen70859@gmail.com","password":"tmarggtg134","login":"Google","ip":"2402:8780:1014:837a:d02b:8ed0:427:508f","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Kedaton","LA","Sunday, 2026-3-15 22:53:00"]},{"email":"vanomerentek00@gmail.com","password":"dolvano.merentek123","login":"Google","ip":"103.76.109.210","extra":["ASN info tidak ditemukan","PT Mahawira Nusantara Grup","Indonesia","Utan","JK","Sunday, 2026-3-15 22:52:53"]},{"email":"mohikbalganiikbal@gmail.com","password":"ikbal9991","login":"Google","ip":"140.213.74.226","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Makassar","SN","Sunday, 2026-3-15 22:51:36"]},{"email":"diegoalvaro128@gmail.com","password":"Anak Medan","login":"Google","ip":"182.9.48.38","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Sunday, 2026-3-15 22:50:30"]},{"email":"kanteandri@gmail.com","password":"stecuuu123","login":"Google","ip":"103.152.232.145","extra":["ASN info tidak ditemukan","PT Kingpolah Network Solutions","Indonesia","Pamanukan","JB","Sunday, 2026-3-15 22:50:18"]},{"email":"habibieputra274@gmail.com","password":"KGELdU0_2QyFTwx","login":"Google","ip":"202.67.47.28","extra":["ASN info tidak ditemukan","PT Hutchison 3 Indonesia","Indonesia","Batam","KR","Sunday, 2026-3-15 22:49:28"]},{"email":"yulihariyanto286@gmail.com","password":"ponorogo","login":"Google","ip":"180.248.13.132","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Kediri","JI","Sunday, 2026-3-15 22:48:25"]},{"email":"zikryakbarmaulana@gmail.com","password":"Zikry Maulana222","login":"Google","ip":"180.244.30.239","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Depok","JB","Sunday, 2026-3-15 22:48:23"]},{"email":"sayfudin797@gmail.com","password":"sayfudin.123","login":"Google","ip":"2400:9800:590:4f9d:1:0:f38a:e2c6","extra":["ASN info tidak ditemukan","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:47:22"]},{"email":"sablenkwiro358@gmail.com","password":"Genshin 123","login":"Google","ip":"103.170.100.69","extra":["ASN info tidak ditemukan","Subnet Data Nusantara","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:46:18"]},{"email":"zayoyaaa@gmail.com","password":"satria107","login":"Google","ip":"103.42.243.200","extra":["ASN info tidak ditemukan","PT Merdeka Media Teknologi","Indonesia","Comal","JT","Sunday, 2026-3-15 22:45:48"]},{"email":"faadil10032013@gmail.com","password":"vivo2026","login":"Google","ip":"140.213.64.200","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:45:25"]},{"email":"robbiq02@gmail.com","password":"rafa1234","login":"Google","ip":"103.148.45.21","extra":["ASN info tidak ditemukan","PT BUANA VISUALNET SENTRA","Indonesia","Bangko","JA","Sunday, 2026-3-15 22:43:10"]},{"email":"082343536986","password":"rapi","login":"Facebook","ip":"202.65.238.58","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:41:48"]},{"email":"hasyaufildzah@gmail.com","password":"hasyaufildzah","login":"Google","ip":"180.252.136.90","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Bekasi","JB","Sunday, 2026-3-15 22:41:28"]},{"email":"andremelda01@gmail.com","password":"andremelda","login":"Google","ip":"182.1.236.171","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:41:27"]},{"email":"ragilmidaerik@gmail.com","password":"rinsosabuncair1892","login":"Google","ip":"103.155.196.150","extra":["ASN info tidak ditemukan","JEMBATANDATA","Indonesia","Sukabumi","JB","Sunday, 2026-3-15 22:40:43"]},{"email":"63 857-2672-4009","password":"850 700","login":"Facebook","ip":"103.147.247.173","extra":["ASN info tidak ditemukan","PLBNET","Indonesia","Pasarkemis","JB","Sunday, 2026-3-15 22:39:55"]},{"email":"nizamnazminkalandra@gmail.com","password":"Palembang21","login":"Google","ip":"125.167.49.7","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:38:39"]},{"email":"083844674026","password":"083844674026tieo","login":"Facebook","ip":"2400:9800:1fe:c08b:189d:c27:5835:e354","extra":["ASN info tidak ditemukan","Indonesia","Cibitung","JB","Sunday, 2026-3-15 22:38:25"]},{"email":"49.0.27.194","password":"ASN info tidak ditemukan","login":"SIMS Jabar Banten Medianet","ip":"Indonesia","extra":["Tunggul","JI","Sunday, 2026-3-15 22:38:10"]},{"email":"vivozodiakblue@gmail.com","password":"bakso ayam","login":"Google","ip":"103.189.0.1","extra":["ASN info tidak ditemukan","PT Interkoneksi Data Nusantara","Indonesia","Sekadau","KB","Sunday, 2026-3-15 22:37:36"]},{"email":"11223344","password":"agil","login":"Facebook","ip":"180.243.9.252","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:36:35"]},{"email":"asbarirama@gmail.com","password":"kaka1108","login":"Google","ip":"103.168.190.147","extra":["ASN info tidak ditemukan","PT Telemedia Komunikasi Pratama","Indonesia","Bekasi","JB","Sunday, 2026-3-15 22:36:07"]},{"email":"nur.hariyadi32@gmail.com","password":"panzzzzzzz","login":"Google","ip":"182.8.225.173","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Yogyakarta","YO","Sunday, 2026-3-15 22:35:51"]},{"email":"uswatunhasanahmida@gmail.com","password":"KONTOLODON","login":"Google","ip":"103.110.34.211","extra":["ASN info tidak ditemukan","PT RECONET SEMESTA INDONESIA","Indonesia","Purwodadi Grobogan","JT","Sunday, 2026-3-15 22:35:20"]},{"email":"pribadiansyah123l@gmail.com","password":"12345AL~good","login":"Google","ip":"36.84.224.215","extra":["ASN info tidak ditemukan","Telkom Indonesia","Indonesia","Mataram","NB","Sunday, 2026-3-15 22:34:44"]},{"email":"rayaatlyuu@gmail.com","password":"ajengfebria","login":"Google","ip":"157.85.212.22","extra":["ASN info tidak ditemukan","PT XL Axiata Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:34:43"]},{"email":"amirulichwan112@gmail.com","password":"fajarnurbaffa","login":"Google","ip":"49.0.27.194","extra":["ASN info tidak ditemukan","SIMS Jabar Banten Medianet","Indonesia","Tunggul","JI","Sunday, 2026-3-15 22:34:27"]},{"email":"180.243.9.252","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Jakarta","JK","Sunday, 2026-3-15 22:34:09"]},{"email":"fanzwafz08@gmail.com","password":"fanz234bld","login":"Google","ip":"114.10.68.25","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:34:04"]},{"email":"hapiskimpis@gmail.com","password":"hapis aja1234","login":"Google","ip":"103.105.57.35","extra":["ASN info tidak ditemukan","PT Lambda Sinergi Telekomunikasi","Indonesia","Sragen","JT","Sunday, 2026-3-15 22:33:57"]},{"email":"ghiansuryaardhani@gmail.com","password":"sariroti","login":"Google","ip":"2402:5680:89f4:aeb5:9c70:dc1b:9caa:2321","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Sunday, 2026-3-15 22:33:53"]},{"email":"aftajubu@gmail.com","password":"ARZAKECE","login":"Google","ip":"180.254.63.95","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tangerang","BT","Sunday, 2026-3-15 22:32:21"]},{"email":"dewidian496@gmail.com","password":"129372047113820","login":"Google","ip":"103.178.13.18","extra":["ASN info tidak ditemukan","PT Amerta Asa Media","Indonesia","Lawang","JI","Sunday, 2026-3-15 22:32:14"]},{"email":"hengki100171@gmail.com","password":"2014523","login":"Google","ip":"114.125.171.202","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Makassar","SN","Sunday, 2026-3-15 22:31:59"]},{"email":"azizanjr26@gmail.com","password":"azizan123456jt","login":"Google","ip":"36.69.59.187","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:30:51"]},{"email":"mamahalvi893@gmail.com","password":"aalpi779","login":"Google","ip":"103.180.123.225","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Duren Tiga","JK","Sunday, 2026-3-15 22:29:27"]},{"email":"sinyakmaneh@gmail.com","password":"syukri.m","login":"Google","ip":"116.206.33.52","extra":["ASN info tidak ditemukan","PT Hutchison 3 Indonesia","Indonesia","Banda Aceh","AC","Sunday, 2026-3-15 22:29:25"]},{"email":"mahbubqalbi860@gmail.com","password":"mahbub123","login":"Google","ip":"116.206.33.52","extra":["ASN info tidak ditemukan","PT Hutchison 3 Indonesia","Indonesia","Banda Aceh","AC","Sunday, 2026-3-15 22:28:51"]},{"email":"111","password":"bott","login":"Google","ip":"203.78.119.83","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Surabaya","JI","Sunday, 2026-3-15 22:27:51"]},{"email":"aminiruhul544@gmail.com","password":"12345678","login":"Facebook","ip":"125.163.60.75","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:27:00"]},{"email":"zainrizkighossan99@gmail.com","password":"zainrizkighossan","login":"Google","ip":"2400:9800:26f:505d:189d:9c4:5760:3fcc","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:26:16"]},{"email":"cielloasik@gmail.com","password":"ciello asik21","login":"Google","ip":"103.173.138.159","extra":["ASN info tidak ditemukan","PT Serayu Multi Connection","Indonesia","Bayunglincir","SS","Sunday, 2026-3-15 22:26:13"]},{"email":"tatantaryana@gmail.com","password":"aku mananusia bukan nabi boyss","login":"Google","ip":"114.10.147.176","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:26:09"]},{"email":"argasxyyzz@gmail.com","password":"123456789","login":"Google","ip":"125.164.196.111","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Malang","JI","Sunday, 2026-3-15 22:24:58"]},{"email":"maulm1181@gmail.com","password":"maul maul01","login":"Google","ip":"103.184.67.47","extra":["ASN info tidak ditemukan","PT Siber Tech Indonesia","Indonesia","Cibulakan","BT","Sunday, 2026-3-15 22:24:11"]},{"email":"ahmadbinanan2@gmail.com","password":"2830","login":"Google","ip":"103.28.116.241","extra":["ASN info tidak ditemukan","PT. Cemerlang Multimedia","Indonesia","Bogor","JB","Sunday, 2026-3-15 22:23:39"]},{"email":"140.213.1.83","password":"ASN info tidak ditemukan","login":"PT Excelcomindo Pratama","ip":"Indonesia","extra":["Makassar","SN","Sunday, 2026-3-15 22:23:17"]},{"email":"maulidadadaa90@gmail.com","password":"Vinacantip_2011","login":"Google","ip":"202.65.236.114","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:25:09"]},{"email":"selumayantie@gmail.com","password":"Gacor@999","login":"Google","ip":"103.147.85.224","extra":["ASN info tidak ditemukan","PT DATA PRIMA SOLUSINDO","Indonesia","Pasarkemis","JB","Sunday, 2026-3-15 22:22:47"]},{"email":"junattan20@gmail.com","password":"1234567","login":"Google","ip":"154.18.252.246","extra":["ASN info tidak ditemukan","PT Wifipedia Sinergi Telematika","Indonesia","South Jakarta","JK","Sunday, 2026-3-15 22:22:44"]},{"email":"140.213.1.83","password":"ASN info tidak ditemukan","login":"PT Excelcomindo Pratama","ip":"Indonesia","extra":["Makassar","SN","Sunday, 2026-3-15 22:22:38"]},{"email":"idonaf801@gmail.com","password":"afan9012","login":"Google","ip":"112.215.229.9","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:22:05"]},{"email":"140.213.1.83","password":"ASN info tidak ditemukan","login":"PT Excelcomindo Pratama","ip":"Indonesia","extra":["Makassar","SN","Sunday, 2026-3-15 22:22:05"]},{"email":"140.213.1.83","password":"ASN info tidak ditemukan","login":"PT Excelcomindo Pratama","ip":"Indonesia","extra":["Makassar","SN","Sunday, 2026-3-15 22:21:27"]},{"email":"faruqkasepbanget02@gmail.com","password":"ujangfaruq02","login":"Google","ip":"103.174.122.219","extra":["ASN info tidak ditemukan","PT Jaya Sejahtra Nugraha","Indonesia","Sumedang","JB","Sunday, 2026-3-15 22:21:07"]},{"email":"085820086152","password":"123456789","login":"Google","ip":"103.108.30.97","extra":["ASN info tidak ditemukan","PT Hutchison 3 Indonesia","Indonesia","Kotawaringin","KT","Sunday, 2026-3-15 22:21:00"]},{"email":"087899683637","password":"dinda adit cahyaraman","login":"Facebook","ip":"103.67.47.62","extra":["ASN info tidak ditemukan","PT JARINGANKU SARANA NUSANTARA","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:19:45"]},{"email":"kristolaba2@gmail.com","password":"NFrbadhHRS8.m4_","login":"Google","ip":"36.68.249.106","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Batam","RI","Sunday, 2026-3-15 22:19:28"]},{"email":"assabianzkiy@gmail.com","password":"ZAKIASSABIAN45","login":"Google","ip":"180.252.237.102","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:19:09"]},{"email":"ubayu5293@gmail.com","password":"ubay2024","login":"Google","ip":"180.247.45.248,168.235.203.243","extra":["ASN info tidak ditemukan","Sunday, 2026-3-15 22:18:57"]},{"email":"zainuddinzufar@gmail.com","password":"20512 1112011","login":"Google","ip":"180.248.35.7","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Malang","JI","Sunday, 2026-3-15 22:18:43"]},{"email":"intannafiaputri0110@gmail.com","password":"tatan111","login":"Google","ip":"140.213.39.220","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:18:30"]},{"email":"tatantar54@gmail.com","password":"aku manusia bukan nabi boys","login":"Google","ip":"114.10.146.176","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:18:31"]},{"email":"ikramihsannasarudin60@gmail.com","password":"hammodhabibi","login":"Google","ip":"103.80.83.30","extra":["ASN info tidak ditemukan","Jaringanku Sarana Nusantara","Indonesia","Ponorogo","JI","Sunday, 2026-3-15 22:18:09"]},{"email":"081352702767","password":"3","login":"Facebook","ip":"114.123.33.163","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Central Jakarta","JK","Sunday, 2026-3-15 22:17:33"]},{"email":"adenoviyanti55@gmail.com","password":"281082","login":"Google","ip":"2001:448a:2074:5cfe:91b4:7164:6d40:880e","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:17:30"]},{"email":"intannadiapitri0110@gmail.com","password":"tatan111","login":"Google","ip":"140.213.39.220","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:17:09"]},{"email":"wijayaanwar067@gmail.com","password":"anwarwijayak067","login":"Google","ip":"103.139.11.10","extra":["ASN info tidak ditemukan","PT. Cemerlang Multimedia","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:17:08"]},{"email":"081270220191","password":"123azam45","login":"Google","ip":"202.65.236.124","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:16:59"]},{"email":"wiranmubarok@gmail.com","password":"wirqn271229","login":"Google","ip":"2400:9800:2c1:4b85:189d:98a:b478:689d","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:16:27"]},{"email":"febitriadisma@gmail.com","password":"febicantik","login":"Google","ip":"103.166.158.239","extra":["ASN info tidak ditemukan","PT Timor Lintas Nusantara","Indonesia","Pangkalan","BT","Sunday, 2026-3-15 22:16:09"]},{"email":"suhadairwan08@gmail.com","password":"faris12345678","login":"Google","ip":"182.3.102.98","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Bandar Lampung","LA","Sunday, 2026-3-15 22:16:03"]},{"email":"azrilnurda@gmail.com","password":"ii","login":"Google","ip":"125.162.82.204","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Dumai","RI","Sunday, 2026-3-15 22:15:29"]},{"email":"sanzz@gmail.com","password":"asumgerengseng","login":"Google","ip":"2400:9800:201:35d8:189d:c90:9fe2:5d20","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Sunday, 2026-3-15 22:15:20"]},{"email":"085166359918","password":"bsda0p12","login":"Facebook","ip":"36.80.17.215","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Sunday, 2026-3-15 22:15:19"]},{"email":"md0528115@gmail.com","password":"wkwkwk123","login":"Google","ip":"2400:9800:670:f0de:48e8:40ff:fe1d:b78c","extra":["ASN info tidak ditemukan","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 22:13:20"]},{"email":"bcisternas547@gmail.com","password":"benja_cbm","login":"Google","ip":"190.109.35.5","extra":["ASN info tidak ditemukan","Dese Technologies Argentina S.A.","Argentina","Bah\u00eda Blanca","B","Sunday, 2026-3-15 22:12:06"]},{"email":"dwipuspita0205utari@gmail.com","password":"aldiansyah112233*","login":"Google","ip":"140.213.34.227","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:11:53"]},{"email":"sabrangd4@gmail.com","password":"Sudarni123","login":"Google","ip":"103.169.188.58","extra":["ASN info tidak ditemukan","Sarana Media Cemerlang","Indonesia","Magetan","JI","Sunday, 2026-3-15 22:11:28"]},{"email":"syamila karomah@gmail.com","password":"samilakaromah","login":"Facebook","ip":"36.81.236.64","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Indonesia","Indonesia","Sindangkerta","JB","Sunday, 2026-3-15 22:10:49"]},{"email":"bagasitam7@gmail.com","password":"tompel kudus","login":"Google","ip":"114.10.104.29","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jambi City","JA","Sunday, 2026-3-15 22:10:01"]},{"email":"basripadde57@gmail.com","password":"AdibRayqal66_!","login":"Google","ip":"183.171.96.109","extra":["ASN info tidak ditemukan","Celcom Axiata Berhad","Malaysia","Kluang","01","Sunday, 2026-3-15 22:09:48"]},{"email":"aprilladian0683@gmail.com","password":"3356","login":"Google","ip":"125.167.48.35","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Palembang","SS","Sunday, 2026-3-15 22:09:43"]},{"email":"firmansyahghifar@gmail.com","password":"gifar234","login":"Google","ip":"103.155.196.151","extra":["ASN info tidak ditemukan","JEMBATANDATA","Indonesia","Sukabumi","JB","Sunday, 2026-3-15 22:08:54"]},{"email":"Hmusthofa962@gmail.com","password":"Haidar_0123","login":"Google","ip":"203.83.32.160,168.235.206.252","extra":["ASN info tidak ditemukan","Sunday, 2026-3-15 22:05:37"]},{"email":"dafaalfatasafaalfata@gmail.com","password":"E1b_xQ7hGd8SzZo","login":"Facebook","ip":"163.223.172.130","extra":["ASN info tidak ditemukan","PT FAFI UIFI NETWORK","Indonesia","Jorong","KS","Sunday, 2026-3-15 22:05:07"]},{"email":"muhammadham969@gmail.com","password":"pesekgalau123","login":"Google","ip":"140.213.32.57","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:05:03"]},{"email":"Zaxxx2127@gmail.com","password":"plenger bet","login":"Google","ip":"125.166.105.10","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:04:53"]},{"email":"mukayatun70@gmail.com","password":"anak yatim","login":"Google","ip":"103.180.118.234","extra":["ASN info tidak ditemukan","PT Persada Data Multimedia","Indonesia","Mojoagung","JI","Sunday, 2026-3-15 22:04:30"]},{"email":"112.215.239.224","password":"ASN info tidak ditemukan","login":"XL-AXIATA Tbk GSM","ip":"Indonesia","extra":["Jakarta","JK","Sunday, 2026-3-15 22:02:09"]},{"email":"rafkana70@gmail.com","password":"123456","login":"Google","ip":"103.156.217.1","extra":["ASN info tidak ditemukan","PT. Meiwa Mold Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:01:38"]},{"email":"Meikoowenpratamapratama@gmail.com","password":"meikoowen  23052012","login":"Google","ip":"103.150.33.153","extra":["ASN info tidak ditemukan","PT BUROQ SARANA INFORMATIKA","Indonesia","Krajan Siki","JI","Sunday, 2026-3-15 22:01:17"]},{"email":"zakyyzakyy970@gmail.com","password":"zakyy675","login":"Google","ip":"2402:8780:103c:4cd2:638f:1db8:af2b:ebaa","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Takalar","SN","Sunday, 2026-3-15 22:01:10"]},{"email":"asiati433@gmail.com","password":"azka faisal  maulana","login":"Google","ip":"182.2.74.246","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Surakarta","JT","Sunday, 2026-3-15 22:00:54"]},{"email":"muhammadagunggp61@gmail.com","password":"FREE FIRE","login":"Google","ip":"2001:448a:5040:10bc:65a5:82da:fa79:a926","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Surabaya","JI","Sunday, 2026-3-15 22:00:22"]},{"email":"083105733020","password":"dian febri","login":"Facebook","ip":"140.213.37.223","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Sunday, 2026-3-15 22:00:10"]},{"email":"bsk.Radhin.@gmail.com","password":"123456789","login":"Google","ip":"165.99.239.11","extra":["ASN info tidak ditemukan","PT MERDEKA TELEKOMUNIKASI CENTER","Indonesia","Mranggen","JT","Sunday, 2026-3-15 21:59:21"]},{"email":"Rajarajajih@gmail.com","password":"Rajagacorr07@","login":"Google","ip":"114.10.134.213","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Makassar","SN","Sunday, 2026-3-15 21:59:20"]},{"email":"asaksawit@gmail.com","password":"asaksawit@gemail.com","login":"Google","ip":"103.184.66.143","extra":["ASN info tidak ditemukan","PT Siber Tech Indonesia","Indonesia","Cicadas","BT","Sunday, 2026-3-15 21:58:21"]},{"email":"Radin ewa@gmail.com","password":"123456789","login":"Google","ip":"165.99.239.11","extra":["ASN info tidak ditemukan","PT MERDEKA TELEKOMUNIKASI CENTER","Indonesia","Mranggen","JT","Sunday, 2026-3-15 21:58:08"]},{"email":"adi949812@gmail.com","password":"ayahmaklon","login":"Google","ip":"182.10.225.104","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Banda Aceh","AC","Sunday, 2026-3-15 21:57:23"]},{"email":"simanjuntakmesrida@gmail.com","password":"juntak88","login":"Google","ip":"36.83.142.230","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Denpasar","BA","Sunday, 2026-3-15 21:57:14"]},{"email":"bendryahmad154@gmail.com","password":"reha123.5","login":"Google","ip":"140.213.45.149","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:57:09"]},{"email":"rafasarafasa536@gmail.com","password":"MUHAMMAD REZA FALEFI 1234","login":"Google","ip":"140.213.99.236","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Bandung","JB","Sunday, 2026-3-15 21:56:56"]},{"email":"Radinismatu@gmail.com","password":"123456789","login":"Google","ip":"165.99.239.11","extra":["ASN info tidak ditemukan","PT MERDEKA TELEKOMUNIKASI CENTER","Indonesia","Mranggen","JT","Sunday, 2026-3-15 21:56:26"]},{"email":"nenestrij@gmail.com","password":"nenes37sari","login":"Google","ip":"2404:c0:1470::d77:32f","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 21:55:35"]},{"email":"165.99.239.11","password":"ASN info tidak ditemukan","login":"PT MERDEKA TELEKOMUNIKASI CENTER","ip":"Indonesia","extra":["Mranggen","JT","Sunday, 2026-3-15 21:55:35"]},{"email":"roofaro74@gmail.com","password":"10054322","login":"Google","ip":"157.15.63.226","extra":["ASN info tidak ditemukan","AMAN ISP Customer Malang","Indonesia","Malang","JI","Sunday, 2026-3-15 21:55:32"]},{"email":"ningratnayulita@gmail.com","password":"2","login":"Google","ip":"103.4.77.81","extra":["ASN info tidak ditemukan","PT Khazanah Net Indonesia","Indonesia","Bogor","JB","Sunday, 2026-3-15 21:54:25"]},{"email":"riyantiaja1207@gmail.com","password":"RiVALBAU123","login":"Google","ip":"103.191.171.138","extra":["ASN info tidak ditemukan","PT Sahabat Manjur Grup","Indonesia","Cianjur","JB","Sunday, 2026-3-15 21:53:31"]},{"email":"tomisyaban@gmail.com","password":"halamadrid","login":"Google","ip":"114.10.65.62","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:52:38"]},{"email":"sholijahsiti@gmail.com","password":"haidar 20120628","login":"Google","ip":"103.105.78.130","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Bojonegoro","JI","Sunday, 2026-3-15 21:51:33"]},{"email":"088294670390","password":"188335622","login":"Facebook","ip":"103.176.96.218","extra":["ASN info tidak ditemukan","PT Global Sarana Elektronika","Indonesia","Subang","JB","Sunday, 2026-3-15 21:51:27"]},{"email":"fitttitik@gmail.com","password":"fitt2828","login":"Google","ip":"182.8.158.21","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Banjarmasin","KS","Sunday, 2026-3-15 21:50:41"]},{"email":"demzzstyle19@gmail.com","password":"09876543","login":"Google","ip":"114.5.217.220","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Sunday, 2026-3-15 21:50:08"]},{"email":"114.10.134.131","password":"ASN info tidak ditemukan","login":"PT. INDOSAT Tbk","ip":"Indonesia","extra":["Makassar","SN","Sunday, 2026-3-15 21:49:47"]},{"email":"dovita003@gmail.com","password":"taa_4yoy","login":"Google","ip":"140.213.230.226","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Palembang","SS","Sunday, 2026-3-15 21:49:47"]},{"email":"Akugyzen@gmail.com","password":"amynedw","login":"Google","ip":"103.155.198.64","extra":["ASN info tidak ditemukan","PT Lintas Jaringan Nusantara","Indonesia","Krajan Rejosari","JI","Sunday, 2026-3-15 21:49:24"]},{"email":"raisatunnada@gmail.com","password":"iwancomot","login":"Google","ip":"140.213.56.172","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Surabaya","JI","Sunday, 2026-3-15 21:48:06"]},{"email":"Alimrayyanrezeki@gmail.com","password":"syahiran","login":"Google","ip":"2405:3800:957:73f6:3916:113d:7dd0:a85a","extra":["ASN info tidak ditemukan","UMobile","Malaysia","Kuala Lumpur","14","Sunday, 2026-3-15 21:47:48"]},{"email":"refanrestu449@gmail.com","password":"000000","login":"Google","ip":"157.20.244.47","extra":["ASN info tidak ditemukan","PT.Global Media Data Prima","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:47:08"]},{"email":"gresiamiagres@gmail.com","password":"12345678955556677788,sncddd","login":"Facebook","ip":"2404:c0:8040::5bb:d5ab","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Pontianak","KB","Sunday, 2026-3-15 21:46:18"]},{"email":"muahaqi012@gmail.com","password":"ninjayuopline","login":"Google","ip":"114.10.44.3","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Semarang","JT","Sunday, 2026-3-15 21:46:08"]},{"email":"087882886498","password":"11maret2009","login":"Facebook","ip":"103.155.198.64","extra":["ASN info tidak ditemukan","PT Lintas Jaringan Nusantara","Indonesia","Krajan Rejosari","JI","Sunday, 2026-3-15 21:46:09"]},{"email":"0887711020298","password":"0887711020298","login":"Google","ip":"114.10.22.24","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:45:56"]},{"email":"brazilsytle3@gmail.com","password":"ht123456789","login":"Google","ip":"2400:9800:c61:50d:a81e:49b2:4c71:88a4","extra":["ASN info tidak ditemukan","Indonesia","Pontianak","KB","Sunday, 2026-3-15 21:45:55"]},{"email":"asumarni8456@gmail.com","password":"ani sumarni","login":"Google","ip":"140.213.41.77","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:44:50"]},{"email":"arkaalarikh123@gmail.com","password":"arka2013","login":"Google","ip":"114.10.40.79","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Medan","SU","Sunday, 2026-3-15 21:44:46"]},{"email":"125.163.112.112","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Bandung","JB","Sunday, 2026-3-15 21:44:38"]},{"email":"08572627262","password":"shshshsdd","login":"Facebook","ip":"2001:448a:10b0:628a:18d9:72a5:4532:ee6b","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:44:29"]},{"email":"sandipermanap488@gmail.com","password":"sandi","login":"Google","ip":"2400:9800:c:f164:189d:7c3:5214:9786","extra":["ASN info tidak ditemukan","Indonesia","South Tangerang","BT","Sunday, 2026-3-15 21:44:17"]},{"email":"Albaralghozali94@gmail.com","password":"al0908bar19","login":"Google","ip":"140.213.33.80","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:42:40"]},{"email":"infinixanjungan63@gmail.com","password":"0401","login":"Google","ip":"2400:9800:c60:6509:f5d3:4a53:324b:94a","extra":["ASN info tidak ditemukan","Indonesia","Pontianak","KB","Sunday, 2026-3-15 21:41:25"]},{"email":"reldialzhafranrizki@gmail.com","password":"reldizhafran2014","login":"Google","ip":"182.11.130.91","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Pontianak","KB","Sunday, 2026-3-15 21:41:14"]},{"email":"lufizakharia29@gmail.com","password":"lufizakaria1234567891011","login":"Facebook","ip":"202.58.197.32","extra":["ASN info tidak ditemukan","Internet Madju Abad Millenindo, PT","Indonesia","Denpasar","BA","Sunday, 2026-3-15 21:41:04"]},{"email":"amalzidan214@gmail.com","password":"jwq!Yp6_f74sPRd","login":"Google","ip":"203.175.102.172","extra":["ASN info tidak ditemukan","PT. Mitra Kita Brilian","Indonesia","Bekasi","JB","Sunday, 2026-3-15 21:40:55"]},{"email":"adlip9571@gmail.com","password":"ADLIPROOO123456","login":"Google","ip":"182.8.225.101","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Yogyakarta","YO","Sunday, 2026-3-15 21:40:43"]},{"email":"nabilapajarina1@gmail.com","password":"pangalengan1234","login":"Google","ip":"2402:5680:876e:c8cc::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Sunday, 2026-3-15 21:40:39"]},{"email":"mansur7789@gmail.com","password":"uuooe000","login":"Google","ip":"2404:c0:b602:6642:226b:ca3:336a:8eff","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Surabaya","JI","Sunday, 2026-3-15 21:40:13"]},{"email":"aji33993@gmail.com","password":"Haikal071708","login":"Google","ip":"140.213.67.84","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Banjarmasin","KS","Sunday, 2026-3-15 21:39:52"]},{"email":"Deren@gmail.com","password":"cX8o!p3u5q3!1-J","login":"Google","ip":"36.83.90.240","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Sunday, 2026-3-15 21:39:44"]},{"email":"deren@gmail.com","password":"cX8o!p3u5q3!1-J","login":"Google","ip":"36.83.90.240","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Sunday, 2026-3-15 21:38:13"]},{"email":"muhammadhaziqdanish2012@gmail.com","password":"haziq2012","login":"Google","ip":"2402:b400:4654:d1da::1","extra":["ASN info tidak ditemukan","YTL Communications","Malaysia","Kampung Larkin Lama","01","Sunday, 2026-3-15 21:38:07"]},{"email":"raffakisaran169@gmail.com","password":"3 november 2012k","login":"Google","ip":"114.122.37.46","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Sunday, 2026-3-15 21:35:30"]},{"email":"085166103967","password":"20121224","login":"Google","ip":"182.1.187.50","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Makassar","SN","Sunday, 2026-3-15 21:34:36"]},{"email":"Singgah1475 @gmail.com","password":"opan141475","login":"Google","ip":"114.5.215.84","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Sunday, 2026-3-15 21:34:29"]},{"email":"140.213.231.246","password":"ASN info tidak ditemukan","login":"PT Excelcomindo Pratama","ip":"Indonesia","extra":["Palembang","SS","Sunday, 2026-3-15 21:34:23"]},{"email":"wkwkqwkwkwk203@gmail.com","password":"3 november 2012olk","login":"Google","ip":"114.122.37.46","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Sunday, 2026-3-15 21:34:07"]},{"email":"elisakbar124@gmail.com","password":"86427531","login":"Google","ip":"125.163.143.36","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Indonesia","Indonesia","Batu","JI","Sunday, 2026-3-15 21:33:00"]},{"email":"bayuunuroktavian1234@gmail.com","password":"bayu nur oktafian","login":"Google","ip":"114.10.143.36","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Banjarmasin","KS","Sunday, 2026-3-15 21:32:50"]},{"email":"Dafaibnu123@gmail.com","password":"ibnuhafif","login":"Google","ip":"103.190.171.64","extra":["ASN info tidak ditemukan","WMS","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:32:38"]},{"email":"airhitam717@gmail.com","password":"isal 12345678.","login":"Google","ip":"2001:448a:1140:29f0:7ff8:7221:10c4:77e7","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Kedaton","LA","Sunday, 2026-3-15 21:32:33"]},{"email":"081913547024","password":"nurulhadipratama23","login":"Facebook","ip":"114.10.39.6","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Sunday, 2026-3-15 21:32:30"]},{"email":"pile3774@gmail.com","password":"poipai78","login":"Google","ip":"114.10.86.229","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Medan","SU","Sunday, 2026-3-15 21:31:47"]},{"email":"faqihkhairirahman898@gmail.com","password":"hvhhih1234\u2075","login":"Google","ip":"113.192.31.246","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Duren Tiga","JK","Sunday, 2026-3-15 21:31:35"]},{"email":"asyraaffathullah130@gmail.com","password":"asyraaf@1123","login":"Google","ip":"2405:3800:90c:d5f4:d3ef:1ab:e69b:c10a","extra":["ASN info tidak ditemukan","UMobile","Malaysia","Kuala Lumpur","14","Sunday, 2026-3-15 21:31:22"]},{"email":"aryasaryas950@gmail.com","password":"aryasaryas123","login":"Google","ip":"202.58.78.116","extra":["ASN info tidak ditemukan","PT DBN","Indonesia","Surabaya","JI","Sunday, 2026-3-15 21:30:13"]},{"email":"anianicomel123@gmail.com","password":"100384","login":"Google","ip":"160.22.204.82","extra":["ASN info tidak ditemukan","PT. PANCA DUTA UTAMA","Indonesia","Kisaran","SU","Sunday, 2026-3-15 21:30:15"]},{"email":"Parhan suparman792@gmail.com","password":"parhan2011 g","login":"Google","ip":"110.138.53.46","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Karawang","JB","Sunday, 2026-3-15 21:29:53"]},{"email":"125.161.160.36","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Jember","JI","Sunday, 2026-3-15 21:29:40"]},{"email":"alfatanfatan00@gmail.com","password":"gmail.com","login":"Google","ip":"103.166.254.83","extra":["ASN info tidak ditemukan","PT Instanet Media Nusantara","Indonesia","Pekanbaru","RI","Sunday, 2026-3-15 21:29:20"]}];
let saved = JSON.parse(sessionStorage.getItem("savedMail") || "[]");
let current = null;
let currentMenu = "inbox";

// ELEMENT
let count = data.length - saved.length;
const sidebar   = document.getElementById("sidebar");
const content   = document.getElementById("content");
const popupEmail = document.getElementById("popupEmail");
const tblDetail = document.getElementById("tblDetail");
const overlay = document.getElementById("overlay");

function toggleSidebar(){
    sidebar.classList.toggle("visible");
    overlay.classList.toggle("show");
}

function closeSidebar(){
    sidebar.classList.remove("visible");
    overlay.classList.remove("show");
}

function closePopup(){
    popupEmail.style.display = "none";
}

function refreshInbox(){
    location.reload();
}

/* AUTO CLOSE JIKA KLIK LUAR POPUP */
popupEmail.addEventListener("click", function(e){
    if(e.target === popupEmail){
        closePopup();
    }
});

// HITUNG JUMLAH
function updateCount(){
    if (count <= 99) {
        document.getElementById("inboxCount").innerText = count;
    }
    document.getElementById("saveCount").innerText = saved.length;
}

// FORMAT JAM
function formatJam(){
    let d = new Date();
    let h = String(d.getHours()).padStart(2,"0");
    let m = String(d.getMinutes()).padStart(2,"0");
    return h + "." + m;
}

// SIMPAN EMAIL
function saveMail(){
    if(current === null) return;

    if(!saved.includes(current)){
        saved.push(current);
        sessionStorage.setItem("savedMail", JSON.stringify(saved));
    }

    popupEmail.style.display = "none";

    if(currentMenu === "saved"){
        showSaved(document.querySelector(".menu-item.active"));
    }else{
        showInbox(document.querySelector(".menu-item.active"));
    }
}

// KOTAK MASUK
function showInbox(el){
    currentMenu = "inbox";
    setActive(el);

    content.innerHTML = `
<div class="title">
    <div class="icon mail"></div>
    <span>Kotak Masuk</span>
</div>
`;

    data.forEach((d,i)=>{
        if(saved.includes(i)) return;

        content.innerHTML += `
<div class="mail-item" onclick="openMail(${i})">
    <div class="avatar"></div>

    <div class="left multi">
        <div class="subject">WEB VANO NESIA</div>
        <div class="subtitle">Result | Punya Si ${d.email}</div>
        <div class="preview">Info Login ${d.login} Email ${d.email}</div>
    </div>

    <div class="right">${formatJam()}</div>
</div>`;
    });

    updateCount();
}

// KOTAK SIMPAN
function showSaved(el){
    currentMenu = "saved";
    setActive(el);

    content.innerHTML = `
<div class="title">
    <div class="icon save"><span></span></div>
    <span>Kotak Simpan</span>
</div>
`;

    if(saved.length === 0){
        content.innerHTML += "<p>Tidak ada data tersimpan</p>";
        updateCount();
        return;
    }

    saved.forEach(i=>{
        let d = data[i];

        content.innerHTML += `
<div class="mail-item" onclick="openMail(${i})">
    <div class="avatar"></div>

    <div class="left multi">
        <div class="subject">WEB VANO NESIA</div>
        <div class="subtitle">Result | Punya Si ${d.email}</div>
        <div class="preview">Info Login ${d.login} Email ${d.email}</div>
    </div>

    <div class="right">Saved</div>
</div>`;
    });

    updateCount();
}

// BUKA DETAIL
function openMail(i){
    let d = data[i];
    tblDetail.innerHTML = `
<tr>
<th colspan="3" style="padding:0;border:none">
<div class="detail-header">
<button class="btn-save" onclick="saveMail()">Simpan</button>
<div class="header-title">Info Login ${d.login}</div>
<button class="close-x" onclick="closePopup()">X</button>
</div>
</th>
</tr>
<tr><td><b>Email</b></td><td colspan="2">${d.email}</td></tr>
<tr><td><b>Password</b></td><td colspan="2">${d.password}</td></tr>
<tr><td><b>Login</b></td><td colspan="2">${d.login}</td></tr>
<tr><td><b>IP</b></td><td colspan="2">${d.ip}</td></tr>
${
    d.extra?.filter(x=>x.trim()!=='').map((e,j)=>`<tr><td><b>Info</b></td><td colspan="2">${e}</td></tr>`).join('')
}
<tr>
<th colspan="3" style="text-align:center;padding:10px;background:#0f172a;color:#fff;font-size:12px;border:none">
ORDER KEY 085776829279
</th>
</tr>
`;
    popupEmail.style.display = "flex";
}

// MENU AKTIF
function setActive(el){
    document.querySelectorAll(".menu-list li")
        .forEach(x=>x.classList.remove("active"));
    if(el) el.classList.add("active");
    closeSidebar();
}

// LINK
function openLink(u){
    window.location.href = u;
}

// LOAD DEFAULT MASUK
showInbox(document.querySelector(".menu-item"));

// TIMER
let end = <?php echo $_SESSION['expire']; ?> * 1000;

function updateTimer() {
    let s = Math.floor((end - Date.now()) / 1000);

    if(s <= 0){
        location.href = "index.php?expired";
        return;
    }

    let hour  = Math.floor(s / 3600);
    let min   = Math.floor((s % 3600) / 60);
    let sec   = s % 60;

    let text = "";

    if(hour > 0){
        text = hour + " JAM " + min + " MENIT";  // <--- ganti h→J, m→M
    }
    else if(min > 0){
        text = min + " MENIT " + sec + " DETIK ";   // <--- ganti m→M, s→S
    }
    else{
        text = sec + " DETIK ";                // <--- s→S
    }

    document.getElementById("timer").innerText = text;
}

updateTimer();
setInterval(updateTimer, 1000);
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"21c7c62f488741ad8ca4cf9f64f7dffb","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script><script>

let end = <?php echo $_SESSION['expire']; ?> * 1000;

function updateTimer(){

let s = Math.floor((end - Date.now()) / 1000);

if(s <= 0){
location.href = "index.php";
return;
}

let min = Math.floor(s / 60);
let sec = s % 60;

document.getElementById("timer").innerText =
" | " + min + " MENIT " + sec + " DETIK";

}

setInterval(updateTimer,1000);

</script>
</body>
</html>