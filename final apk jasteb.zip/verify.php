<?php
session_start();

if(!isset($_GET['verified'])){
echo "Akses tidak valid";
exit;
}

function generateKey($length = 12){
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $key = '';
    for($i = 0; $i < $length; $i++){
        $key .= $chars[rand(0, strlen($chars)-1)];
    }
    return $key;
}

$key = generateKey();

$_SESSION['key'] = $key;
$_SESSION['expire'] = time() + 60; // 1 menit
?>

<!DOCTYPE html>
<html>
<head>

<title>Generate Key</title>

<style>

body{
background:#0f172a;
color:white;
font-family:sans-serif;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.box{
background:#1e293b;
padding:30px;
border-radius:15px;
text-align:center;
width:300px;
}

.key{
font-size:24px;
font-weight:bold;
margin:15px 0;
color:#22c55e;
}

button{
padding:10px 15px;
border:none;
border-radius:8px;
cursor:pointer;
margin:5px;
}

.copy{
background:#22c55e;
color:white;
}

.login{
background:#3b82f6;
color:white;
}

</style>

</head>

<body>

<div class="box">

<h2>KEY ANDA</h2>

<div class="key" id="key"><?php echo $key; ?></div>

<button class="copy" onclick="copyKey()">COPY KEY</button>

<br><br>

<a href="index.php">
<button class="login">LOGIN KEY</button>
</a>

<p>Key berlaku 60 detik</p>

</div>

<script>

function copyKey(){

let key = document.getElementById("key").innerText;

navigator.clipboard.writeText(key);

alert("Key berhasil disalin");

}

</script>

</body>
</html>