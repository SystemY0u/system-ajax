<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Key UI - Premium</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    body { font-family: 'Poppins', sans-serif; background: #020617; color: white; }
.glass { background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
.fade-in { animation: fadeIn 0.5s ease forwards; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.notif { padding: 8px 12px; border-radius: 8px; margin-bottom: 8px; font-weight: 500; }
.notif.error { background: #ff4d4f; color: white; }
.notif.success { background: #52c41a; color: white; }

        body { 
            font-family: 'Poppins', sans-serif; 
            background: #020617; 
            color: white; 
            margin: 0;
            overflow-x: hidden;
        }
        .glass { 
            background: rgba(15, 23, 42, 0.4); 
            backdrop-filter: blur(16px) saturate(180%); 
            border: 1px solid rgba(255, 255, 255, 0.1); 
        }
        .glass-card {
            background: rgba(30, 41, 59, 0.4);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        }
        .fade-in { 
            animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; 
        }
        @keyframes fadeIn { 
            from { opacity: 0; transform: translateY(10px); } 
            to { opacity: 1; transform: translateY(0); } 
        }
        .animate-float {
            animation: float 6s ease-in-out infinite;
        }
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }
        .notif { padding: 12px 16px; border-radius: 12px; margin-bottom: 16px; font-weight: 500; font-size: 0.875rem; text-align: center; }
        .notif.error { background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.5); color: #fca5a5; }
        .notif.success { background: rgba(16, 185, 129, 0.2); border: 1px solid rgba(16, 185, 129, 0.5); color: #6ee7b7; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <!-- Background Elements -->
    <div class="fixed inset-0 pointer-events-none -z-10">
        <div class="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div class="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-600/20 rounded-full blur-[120px] animate-pulse" style="animation-delay: 2s;"></div>
    </div>

    <!-- Popup Modal -->
    <div id="popup" class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm transition-opacity duration-300">
        <div class="glass-card max-w-lg w-full p-8 rounded-[2rem] relative fade-in mx-4">
            <button id="closePopup" class="absolute top-6 right-6 text-gray-400 hover:text-white transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <div class="text-center space-y-6">
                <div class="space-y-2">
                    <h2 class="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-400">Info Official</h2>
                    <p class="text-gray-400">Nikmati pengalaman premium dengan fitur eksklusif dan keamanan terbaik.</p>
                </div>
                
                <div class="grid grid-cols-1 gap-4">
                    <a href="https://whatsapp.com/channel/0029VbCI4TM1SWt57WBSHJ1c" class="flex items-center justify-center gap-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 px-6 py-4 rounded-2xl text-white font-bold transition-all shadow-lg hover:shadow-amber-500/20">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        DOWNLOAD APK
                    </a>
                    <a href="https://whatsapp.com/channel/0029VbCI4TM1SWt57WBSHJ1c" class="flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 px-6 py-4 rounded-2xl text-white font-bold transition-all shadow-lg hover:shadow-emerald-500/20">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        ORDER KEY PERJAM
                    </a>
                    <a href="https://sfl.gl/60tgbBUR" class="flex items-center justify-center gap-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 px-6 py-4 rounded-2xl text-white font-bold transition-all shadow-lg hover:shadow-emerald-500/20">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        KEY FREE 1 MENITAN
                    </a>
                </div>

                <div class="flex gap-4">
                    <a href="https://whatsapp.com/channel/0029VbC3mNuKmCPT0R5T9t0M" class="flex-1 flex items-center justify-center gap-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#25D366] px-4 py-4 rounded-2xl font-semibold transition-all">
                        WhatsApp 
                    </a>
                    <a href="https://t.me/apkjasteb" class="flex-1 flex items-center justify-center gap-2 bg-[#0088cc]/10 hover:bg-[#0088cc]/20 border border-[#0088cc]/30 text-[#0088cc] px-4 py-4 rounded-2xl font-semibold transition-all">
                        Telegram
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Login Card -->
<div class="glass max-w-md w-full p-8 rounded-3xl shadow-2xl relative z-10 text-center">
    <div class="w-20 h-20 bg-blue-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-blue-500/30">
        <img src="assets/logo.png" alt="Logo" class="w-16 h-16 object-contain">
    </div>
    <h1 class="text-3xl font-bold tracking-tight mb-2">LOGIN KEY</h1>
    <p class="text-gray-400 text-sm mb-8">Silahkan masukkan key aktif anda untuk memulai akses</p>

    
    <form action="cekkey.php" method="POST">

<input type="text" name="user_key" placeholder="MASUKKAN KEY ANDA" 
class="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-4 mb-4 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-center font-mono" required>
        <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-emerald-600 py-4 rounded-xl font-bold shadow-lg shadow-blue-900/20 hover:scale-[1.02] active:scale-95 transition-all">
            MASUK SEKARANG
        </button>
    </form>

    <div class="mt-8 pt-8 border-t border-slate-800 flex justify-center gap-6">
        <a href="#" class="text-red-500 opacity-70 hover:opacity-100 transition-opacity">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 2-2 24.47 24.47 0 0 1 15 0 2 2 0 0 1 2 2 24.12 24.12 0 0 1 0 10 2 2 0 0 1-2 2 24.47 24.47 0 0 1-15 0 2 2 0 0 1-2-2Z"></path><path d="m10 15 5-3-5-3z"></path></svg>
        </a>
        <a href="#" class="text-emerald-500 opacity-70 hover:opacity-100 transition-opacity">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
        </a>
    </div>

    <p class="mt-6 text-[10px] text-slate-500 uppercase tracking-widest">&copy; 2026 GANZZ GANTENG - ALL RIGHTS RESERVED</p>
</div>

<!-- Script Popup -->
<script>
const popup = document.getElementById('popup');
const closeBtn = document.getElementById('closePopup');

closeBtn.addEventListener('click', () => {
    popup.style.display = 'none';
});
</script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"21c7c62f488741ad8ca4cf9f64f7dffb","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>