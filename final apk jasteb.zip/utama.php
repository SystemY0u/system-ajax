<?php
session_start();

if(!isset($_SESSION['login'])){
header("Location: index.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gmail UI</title>

<style>
body{margin:0;font-family:Arial;background:#f6f8fc}

/* TOPBAR */
.topbar{
    position:fixed;top:0;left:0;width:100%;height:55px;
    background:#fff;border-bottom:1px solid #ddd;
    display:flex;align-items:center;padding:0 15px;z-index:99
}
.menu-icon{font-size:26px;cursor:pointer;margin-right:15px}
.logo{font-size:22px;font-weight:bold;color:#d93025}
#timer{
    font-size:16px;   /* samakan ukuran dengan logo */
    color:#555;
    margin-left:auto; /* dorong ke paling kanan */
}

/* SIDEBAR */
.sidebar{
    position:fixed;top:55px;left:0;width:240px;
    height:calc(100% - 55px);background:#fff;
    border-right:1px solid #ddd;
    transform:translateX(-260px);
    transition:.3s;z-index:90;padding:15px
}
.sidebar.visible{transform:translateX(0)}
.menu-list{list-style:none;padding:0;margin:0}
.menu-list li{
    padding:12px;border-radius:8px;
    cursor:pointer;margin-bottom:6px
}
.menu-list li:hover{background:#f1f3f4}
.menu-list li.active{
    background:#e3e7ff;
    font-weight:bold;
    border-left:4px solid #3558ff
}

/* CONTENT */
.content{padding:80px 20px}
.mail-item{
    background:#fff;padding:12px 15px;
    border-radius:10px;border:1px solid #ddd;
    display:flex;justify-content:space-between;
    margin-bottom:10px;cursor:pointer
}
.mail-item:hover{background:#f1f3f4}
.mail-item.read{background:#eee;color:#777}

/* POPUP */
#popupEmail{
    position:fixed;inset:0;
    background:rgba(0,0,0,.4);
    display:none;align-items:center;justify-content:center;
    z-index:999
}
.popup-box{
    background:transparent;
    width:95%;
    max-width:450px;
    padding:0;
    border-radius:0;
}

.tblResult{width:100%;border-collapse:collapse}
.tblResult th{background:#001240;color:#fff;padding:10px}
.tblResult td{border:2px solid #001240;padding:8px}
.close-btn{
    background:#d93025;color:#fff;
    border:none;padding:8px 15px;
    border-radius:8px;cursor:pointer
}
.mail-item{
    background:#fff;
    padding:10px 15px;
    border-radius:10px;
    border:1px solid #ddd;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:10px;
    cursor:pointer;
    overflow:hidden;
}

.mail-item .left{
    max-width:75%;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.mail-item .right{
    flex-shrink:0;
    font-size:13px;
    color:#666;
}
.sidebar-header{
    text-align:center;
    padding-bottom:15px;
    border-bottom:1px solid #eee;
    margin-bottom:10px;
}
.sidebar-header img{
    width:70px;
    margin-bottom:8px;
}
.sidebar-header a{
    display:inline-block;
    margin-top:6px;
    padding:6px 14px;
    background:#1db954;
    color:#fff;
    border-radius:20px;
    text-decoration:none;
    font-size:12px;
}
.menu-item{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.badge{
    background:#d93025;
    color:#fff;
    font-size:12px;
    padding:2px 8px;
    border-radius:12px;
}
.join-btn{
    display:inline-block;
    margin-top:6px;
    padding:6px 14px;
    background:#1db954; /* hijau */
    color:#fff;
    border-radius:20px;
    text-decoration:none;
    font-size:12px;
}

.join-btn:hover{
    background:#17a44a;
}
.tblResult{
    width:100%;
    border-collapse:separate; /* PENTING */
    border-spacing:0;
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,.15);
}
.wrap{
    word-break: break-all;
    line-height:1.4;
}
/* HEADER DETAIL LOGIN */
.detail-header{
    position:relative;
    background:#0f172a;
    color:#fff;
    padding:12px 42px 12px 12px;
    border-radius:8px 8px 0 0;
    font-size:15px;
    font-weight:bold;
}

/* TOMBOL X */
.close-x{
    position:absolute;
    top:8px;
    right:10px;
    background:transparent;
    border:none;
    color:#fff;
    font-size:20px;
    cursor:pointer;
    line-height:1;
}

.close-x:hover{
    color:#ff4d4d;
}

/* TITLE */
.title{
    display:flex;
    align-items:center;
    gap:8px;
    font-size:19px;
    font-weight:500;
    color:#202124;
    margin-bottom:14px;
}

/* BASE ICON */
.icon{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

/* ===================== */
/* ENVELOPE (SURAT) */
/* ===================== */
.icon.mail{
    border:2px solid #3c4043;
    border-radius:2px;
}

.icon.mail::before{
    content:"";
    position:absolute;
    left:2px;
    right:2px;
    top:5px;
    height:8px;
    border-left:2px solid #3c4043;
    border-right:2px solid #3c4043;
}

.icon.mail::after{
    content:"";
    position:absolute;
    left:2px;
    right:2px;
    top:4px;
    height:2px;
    background:#3c4043;
}

/* ===================== */
/* TRASH (GMAIL STYLE) */
/* ===================== */
.icon.bin{
    border:2px solid #3c4043;
    border-top:none;
    border-radius:0 0 2px 2px;
}

.icon.bin::before{
    content:"";
    position:absolute;
    top:-5px;
    left:-2px;
    width:22px;
    height:2px;
    background:#3c4043;
}

.icon.bin::after{
    content:"";
    position:absolute;
    top:4px;
    left:6px;
    width:2px;
    height:8px;
    background:#3c4043;
    box-shadow:4px 0 0 #3c4043;
}

.left.multi{
    display:flex;
    flex-direction:column;
    gap:3px;
    max-width:75%;
}

.subject{
    font-weight:bold;
    font-size:15px;
    color:#202124;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.subtitle{
    font-size:13px;
    color:#202124;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

.preview{
    font-size:12px;
    color:#5f6368;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
.detail-header{
    background:#0f172a;
    color:#fff;
    padding:12px 10px;
    display:grid;
    grid-template-columns:auto 1fr auto;
    align-items:center;
    border-radius:12px 12px 0 0;
}

/* JUDUL TENGAH */
.header-title{
    text-align:center;
    font-size:15px;
    font-weight:bold;
}

/* SIMPAN */
.btn-save{
    background:#22c55e;
    border:none;
    color:#fff;
    padding:6px 12px;
    border-radius:10px;
    font-size:13px;
    cursor:pointer;
}

/* HAPUS */
.btn-delete{
    background:#ef4444;
    border:none;
    color:#fff;
    padding:6px 12px;
    border-radius:10px;
    font-size:13px;
    cursor:pointer;
}

.btn-save:hover{background:#16a34a}
.btn-delete:hover{background:#dc2626}

.avatar{
    width:38px;
    height:38px;
    border-radius:50%;
    background:#d1d5db;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}

.avatar::before{
    content:"";
    width:14px;
    height:14px;
    background:#9ca3af;
    border-radius:50%;
    position:absolute;
    transform:translateY(-6px);
}

.avatar::after{
    content:"";
    width:20px;
    height:10px;
    background:#9ca3af;
    border-radius:10px 10px 0 0;
    position:absolute;
    transform:translateY(8px);
}

.mail-item{
    gap:12px;
}
/* ===================== */
/* PIN / SAVE ICON */
/* ===================== */
.icon.pin{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

.icon.pin::before{
    content:"";
    position:absolute;
    top:0;
    left:4px;
    width:10px;
    height:10px;
    background:#3c4043;
    border-radius:50%;
}

.icon.pin::after{
    content:"";
    position:absolute;
    top:9px;
    left:8px;
    width:2px;
    height:9px;
    background:#3c4043;
    transform:rotate(20deg);
}
/* ===================== */
/* SAVE / SIMPAN (STACK MAIL) */
/* ===================== */
.icon.save{
    width:18px;
    height:18px;
    position:relative;
    flex-shrink:0;
}

/* kotak belakang */
.icon.save::before{
    content:"";
    position:absolute;
    top:3px;
    left:3px;
    width:12px;
    height:10px;
    border:2px solid #3c4043;
    border-radius:2px;
    opacity:.6;
}

/* amplop depan */
.icon.save::after{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:14px;
    height:10px;
    border:2px solid #3c4043;
    border-radius:2px;
    background:#fff;
}

/* garis amplop */
.icon.save span{
    position:absolute;
    top:4px;
    left:2px;
    width:10px;
    height:2px;
    background:#3c4043;
}
/* OVERLAY UNTUK CLOSE SIDEBAR */
.overlay{
    position:fixed;
    top:55px;
    left:0;
    width:100%;
    height:calc(100% - 55px);
    background:transparent;
    z-index:80;
    display:none;
}
.overlay.show{
    display:block;
}
.btn-refresh{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    margin:0 6px;
    cursor:pointer;
    font-size:1em; /* sama ukuran dengan tulisan Gmail */
    transition:0.2s;
}

.btn-refresh:hover{
    transform:rotate(180deg);
}
</style>
</head>

<body>

<!-- TOPBAR -->
<div class="topbar">
    <div class="menu-icon" onclick="toggleSidebar()">☰</div>
    <div class="logo">Gmail<span class="btn-refresh" onclick="refreshInbox()">⟳</span><span id="timer"></span>
    </div>
</div>

<!-- SIDEBAR -->
<div class="sidebar" id="sidebar">

    <!-- LOGO + JOIN -->
    <div class="sidebar-header">
        <img src="assets/logo.png" alt="Logo">

        <div class="reseller">
            <b>Join Reseller</b><br>
            Hubungi Admin<br>
            <a href="javascript:void(0)" class="join-btn" onclick="openLink('https://t.me/apkjasteb')">
    Klik di sini
</a>
        </div>
    </div>

    <!-- MENU -->
    <ul class="menu-list">

        <li class="menu-item" onclick="showInbox(this)">
    <span style="display:flex;align-items:center;gap:10px">
        <div class="icon save"><span></span></div>
        Masuk
    </span>
    <span class="badge" id="inboxCount">99+</span>
        </li>

        <li class="menu-item" onclick="showSaved(this)">
    <span style="display:flex;align-items:center;gap:10px">
        <div class="icon save"><span></span></div>
        Simpan
    </span>
    <span class="badge" id="saveCount">0</span>
</li>

        <hr>

        <li class="menu-item" onclick="openLink('https://whatsapp.com/channel/0029VbCI4TM1SWt57WBSHJ1c')">
            <span class="menu-text">🔰𝗬𝗼𝘂𝘁𝘂𝗯𝗲</span>
        </li>

        <li class="menu-item" onclick="openLink('https://whatsapp.com/channel/0029VbCI4TM1SWt57WBSHJ1c')">
            <span class="menu-text">🔰𝗧𝗶𝗸𝘁𝗼𝗸</span>
        </li>

        <li class="menu-item" onclick="openLink('https://whatsapp.com/channel/0029VbCI4TM1SWt57WBSHJ1c')">
            <span class="menu-text">🔰𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽</span>
        </li>

    </ul>
</div>

<div class="overlay" id="overlay" onclick="closeSidebar()"></div>

<!-- CONTENT -->
<div class="content" id="content"></div>

<!-- POPUP -->
<div id="popupEmail">
    <div class="popup-box">
        <table class="tblResult" id="tblDetail"></table>
    </div>
</div>

<script>
let data = [{"email":"182.1.228.156","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Palembang","SS","Monday, 2026-3-16 06:36:52"]},{"email":"Aidilzxcvr@gmail.com","password":"ru123456","login":"Google","ip":"140.213.71.61","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Palembang","SS","Monday, 2026-3-16 06:34:13"]},{"email":"36.76.172.71","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 06:34:11"]},{"email":"36.76.172.71","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 06:34:11"]},{"email":"36.76.172.71","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 06:34:11"]},{"email":"36.76.172.71","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 06:34:10"]},{"email":"36.76.172.71","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 06:34:10"]},{"email":"bungobambang72@gmail.com","password":"1226745674534590","login":"Google","ip":"36.76.172.71","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Medan","SU","Monday, 2026-3-16 06:34:09"]},{"email":"36.77.209.238","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Jakarta","JK","Monday, 2026-3-16 06:34:06"]},{"email":"javjepang13@gmail.com","password":"bapakkau","login":"Google","ip":"36.77.209.238","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:34:04"]},{"email":"luthfiardani04@gmail.com","password":"albiganteng","login":"Google","ip":"103.133.62.10","extra":["ASN info tidak ditemukan","TLINK","Indonesia","Bangunrejo","LA","Monday, 2026-3-16 06:33:44"]},{"email":"36.79.102.80","password":"ASN info tidak ditemukan","login":"PT. Telekomunikasi Indonesia","ip":"Indonesia","extra":["Surabaya","JI","Monday, 2026-3-16 06:33:32"]},{"email":"ridwanusrberyy@gmail.com","password":"110706","login":"Google","ip":"114.10.139.134","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Tarakan","KU","Monday, 2026-3-16 06:32:26"]},{"email":"bintangdini173@gmail.com","password":"13141","login":"Google","ip":"114.10.82.81","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Medan","SU","Monday, 2026-3-16 06:32:11"]},{"email":"zsunda7@gmail.com","password":"ZALLXALOKK","login":"Google","ip":"2402:5680:930b:c0d9::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 06:31:42"]},{"email":"miftanurohman@gmail.com","password":"mifta1234@","login":"Google","ip":"114.10.152.173","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Surakarta","JT","Monday, 2026-3-16 06:30:56"]},{"email":"fitrilia5755@gmail.com","password":"MEDAN2025","login":"Google","ip":"182.9.35.205","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 06:30:51"]},{"email":"ariss08115@gmail.com","password":"ariss","login":"Google","ip":"140.213.169.93","extra":["ASN info tidak ditemukan","PT XL Axiata Tbk","Indonesia","Semarang","JT","Monday, 2026-3-16 06:29:42"]},{"email":"182.10.161.216","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Cirebon","JB","Monday, 2026-3-16 06:29:31"]},{"email":"ujangdimasd@gmail.com","password":"127308","login":"Facebook","ip":"114.5.248.144","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jatiluhur","JB","Monday, 2026-3-16 06:27:06"]},{"email":"dynsyah907@gmail.com","password":"Ardy2008","login":"Google","ip":"45.198.32.249","extra":["ASN info tidak ditemukan","PT Global Media Data Prima","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:26:46"]},{"email":"patih16588@gmail.com","password":"aku123baik","login":"Google","ip":"103.157.78.102","extra":["ASN info tidak ditemukan","PT Super Media Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:26:16"]},{"email":"083125347287","password":"romanur","login":"Facebook","ip":"147.139.180.64","extra":["ASN info tidak ditemukan","Alibaba Cloud LLC","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:25:50"]},{"email":"Punyabadar88@gmail.com","password":"punyokuu","login":"Google","ip":"114.10.98.115","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Palembang","SS","Monday, 2026-3-16 06:25:11"]},{"email":"bakri.sa12@gmail.com","password":"RASYA123324","login":"Google","ip":"27.123.223.41","extra":["ASN info tidak ditemukan","FIBERNET","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:25:07"]},{"email":"hernisriutami@gmail.com","password":"herniseriutami","login":"Google","ip":"103.141.108.177","extra":["ASN info tidak ditemukan","Data Buana Nusantara","Indonesia","Ngoro","JI","Monday, 2026-3-16 06:24:51"]},{"email":"elfangnt@gmail.com","password":"wong ean","login":"Google","ip":"103.190.170.85","extra":["ASN info tidak ditemukan","PT Ring Media Nusantara","Indonesia","Wonosari","YO","Monday, 2026-3-16 06:24:20"]},{"email":"rizkymaulanapratama67@gmail.com","password":"rizkymp12345","login":"Google","ip":"157.85.207.62","extra":["ASN info tidak ditemukan","XLNET","Indonesia","Cibitung","JB","Monday, 2026-3-16 06:24:20"]},{"email":"36.79.125.13","password":"ASN info tidak ditemukan","login":"PT. Telekomunikasi Indonesia","ip":"Indonesia","extra":["Surabaya","JI","Monday, 2026-3-16 06:21:19"]},{"email":"fadlihermaneli@gmail.com","password":"FADLI12345678","login":"Google","ip":"140.213.125.177","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Rokan","RI","Monday, 2026-3-16 06:20:38"]},{"email":"putramkamil65@gmail.com","password":"112233","login":"Google","ip":"182.5.133.202","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Cirebon","JB","Monday, 2026-3-16 06:20:15"]},{"email":"realmesaiful9@gmail.com","password":"AFIF2009","login":"Google","ip":"160.19.18.81","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Kediri","JI","Monday, 2026-3-16 06:20:10"]},{"email":"akbarirr66@gmail.com","password":"bintang barz","login":"Google","ip":"182.8.226.136","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Yogyakarta","YO","Monday, 2026-3-16 06:19:49"]},{"email":"vivoy20s1441@gmail.com","password":"112233445566778811223","login":"Google","ip":"210.87.78.253","extra":["ASN info tidak ditemukan","PT Rajawali Bintang Cemerlang Telkomedia","Indonesia","Bandung","JB","Monday, 2026-3-16 06:19:46"]},{"email":"082335713642","password":"736271","login":"Google","ip":"114.125.207.13","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Makassar","SN","Monday, 2026-3-16 06:19:35"]},{"email":"114.125.207.13","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Makassar","SN","Monday, 2026-3-16 06:19:35"]},{"email":"673773737","password":"123864684","login":"Facebook","ip":"2404:c0:5610::364:dcb6","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Tangerang","BT","Monday, 2026-3-16 06:18:31"]},{"email":"673773737","password":"123864684","login":"Facebook","ip":"2404:c0:5610::364:dcb6","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Tangerang","BT","Monday, 2026-3-16 06:18:31"]},{"email":"taufik5775m@gmail.com","password":"capkakitiga","login":"Google","ip":"180.246.230.215","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Pare","JI","Monday, 2026-3-16 06:17:53"]},{"email":"junaazkapratama02@gmail.com","password":"atreamer7_8","login":"Google","ip":"202.51.215.62","extra":["ASN info tidak ditemukan","PT. Sejahtera Globalindo","Indonesia","Denpasar","BA","Monday, 2026-3-16 06:17:24"]},{"email":"rafka @gmail.com","password":"rafka","login":"Facebook","ip":"2402:5680:877f:4820::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 06:17:18"]},{"email":"082388801219","password":"ilhamdi123","login":"Google","ip":"103.156.248.35","extra":["ASN info tidak ditemukan","Trans Media Telekomunikasi","Indonesia","Batam","RI","Monday, 2026-3-16 06:17:17"]},{"email":"alfinnnn123hafiz@gmail.com","password":"alfin 02","login":"Google","ip":"2404:c0:4c5a:34d7:99ce:77dd:d877:c1a7","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Batulicin","KS","Monday, 2026-3-16 06:16:15"]},{"email":"ramadanirama620@gmail.com","password":"pD97674acH7t-sE","login":"Google","ip":"110.136.187.158","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tangerang","BT","Monday, 2026-3-16 06:15:52"]},{"email":"irjan507@gmail.com","password":"rafka","login":"Google","ip":"2402:5680:877f:4820::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 06:15:43"]},{"email":"sahegabukja@gmail.com","password":"1009911228877334466","login":"Google","ip":"2404:c0:9456:f8d0:4da5:8746:1ac2:b447","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 06:15:43"]},{"email":"amboassek60@gmail.com","password":"12345678","login":"Google","ip":"202.65.238.249","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:15:32"]},{"email":"alinalin8272@gmail.com","password":"82726","login":"Google","ip":"125.163.67.136","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:14:00"]},{"email":"bebengbauk@gmail.com","password":"fizi1w34545","login":"Google","ip":"2400:9800:461:922c:24ac:caff:fede:d42f","extra":["ASN info tidak ditemukan","Indonesia","Medan","SU","Monday, 2026-3-16 06:13:43"]},{"email":"Alfinnnn123hafiz@gmail.com","password":"alfin 02","login":"Google","ip":"2404:c0:4c5a:34d7:99ce:77dd:d877:c1a7","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Batulicin","KS","Monday, 2026-3-16 06:13:38"]},{"email":"liaandriyamiandriyami@gmail.com","password":"guagacor231011","login":"Google","ip":"103.27.193.100","extra":["ASN info tidak ditemukan","PT Juli Digital Nusantara","Indonesia","Slamanyah","JB","Monday, 2026-3-16 06:13:09"]},{"email":"rohmanabdulah100@gmail.com","password":"raffa155","login":"Google","ip":"2404:c0:2910::696:4721","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Bandung","JB","Monday, 2026-3-16 06:13:03"]},{"email":"25974","password":"3di","login":"Google","ip":"125.160.113.95","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Samarinda","KI","Monday, 2026-3-16 06:12:27"]},{"email":"nopendrirajas@gmail.com","password":"FF kipas123","login":"Google","ip":"182.1.237.146","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Palembang","SS","Monday, 2026-3-16 06:12:01"]},{"email":"Abudawar74@gmail.com","password":"abudawar1970","login":"Google","ip":"202.65.225.70","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:09:24"]},{"email":"dikimaulanadiki80@gmail.com","password":"dikibaik123","login":"Google","ip":"103.172.122.35","extra":["ASN info tidak ditemukan","PRIME","Indonesia","Taloko","NB","Monday, 2026-3-16 06:09:04"]},{"email":"a36623262@gmail.com","password":"12345sm","login":"Google","ip":"103.148.130.18","extra":["AS141127 PT Anugerah Cimanuk Raya","PT Anugerah Cimanuk Raya","Indonesia","Indramayu","JB","Monday, 2026-3-16 06:09:05"]},{"email":"sdiraya2@gmail.com","password":"Diraya123","login":"Google","ip":"2402:5680:930e:8c66:4476:48ff:fe49:6a0","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 06:06:54"]},{"email":"akunkecil5a@gmail.com","password":"@gung.bakar","login":"Google","ip":"114.122.68.188","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Bandung","JB","Monday, 2026-3-16 06:06:38"]},{"email":"mamahunamah569@gmail.com","password":"unamah","login":"Google","ip":"36.83.131.74","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Denpasar","BA","Monday, 2026-3-16 06:05:41"]},{"email":"alwip774@gmail.com","password":"alwi161213@","login":"Google","ip":"125.162.212.8","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Monday, 2026-3-16 06:05:22"]},{"email":"darmadiabyandra@gmail.com","password":"49948670","login":"Google","ip":"2404:c0:1960::adc:5953","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Palembang","SS","Monday, 2026-3-16 06:04:48"]},{"email":"ap3345802@gmail.com","password":"jwgtsit4wovt","login":"Google","ip":"103.172.70.37","extra":["ASN info tidak ditemukan","AZNET","Indonesia","Palimanan","JB","Monday, 2026-3-16 06:04:21"]},{"email":"diankakak324@gmail.com","password":"diankaka","login":"Facebook","ip":"110.136.144.91","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Sukabumi","JB","Monday, 2026-3-16 06:03:41"]},{"email":"0880","password":"49948906","login":"Google","ip":"2404:c0:1960::adc:5953","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Palembang","SS","Monday, 2026-3-16 06:03:35"]},{"email":"hafizyasid9@gmail.com","password":"hafiznafizha","login":"Google","ip":"210.87.92.28","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Krajan Wetan Wonojoyo","JI","Monday, 2026-3-16 06:03:32"]},{"email":"Azril@gmail.com","password":"123456","login":"Google","ip":"114.5.108.66","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Surabaya","JI","Monday, 2026-3-16 06:03:28"]},{"email":"089764463789","password":"LAGI NEBAR NIH","login":"Facebook","ip":"160.19.226.244","extra":["ASN info tidak ditemukan","PT. Cemerlang Multimedia","Indonesia","Bandung","JB","Monday, 2026-3-16 06:03:23"]},{"email":"8563733202","password":"12345678910","login":"Google","ip":"114.10.155.218","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Malang","JI","Monday, 2026-3-16 06:02:51"]},{"email":"182.2.7.37","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Batam","RI","Monday, 2026-3-16 06:02:50"]},{"email":"azrilphone60@gmail.com","password":"12345678","login":"Google","ip":"114.5.108.66","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Surabaya","JI","Monday, 2026-3-16 06:02:20"]},{"email":"182.2.7.37","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Batam","RI","Monday, 2026-3-16 06:01:35"]},{"email":"tarmadpadil@gmail.com","password":"unamah","login":"Google","ip":"36.83.131.74","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Denpasar","BA","Monday, 2026-3-16 06:01:17"]},{"email":"amaramar66782@gmail.com","password":"amaramar","login":"Google","ip":"112.215.174.237","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Jakarta","JK","Monday, 2026-3-16 06:01:09"]},{"email":"ajaayong216@gmail.com","password":"123","login":"Google","ip":"182.2.7.37","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Batam","RI","Monday, 2026-3-16 06:00:52"]},{"email":"fadlyishaq97@gmail.com","password":"98734563","login":"Google","ip":"2404:c0:ca02:7eb7:b0a5:a577:7319:d104","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Pontianak","KB","Monday, 2026-3-16 06:00:40"]},{"email":"riskitayo234@gmail.com","password":"Rexx mod sad332211","login":"Google","ip":"114.10.10.22","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Semarang","JT","Monday, 2026-3-16 05:59:57"]},{"email":"gayasoksok@gmail.com","password":"arfa.12345","login":"Google","ip":"140.213.159.204","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Banjar Badung","BA","Monday, 2026-3-16 05:59:54"]},{"email":"Iki ep ep@gmail.com","password":"2617162527","login":"Google","ip":"202.58.73.26","extra":["ASN info tidak ditemukan","PT Data Buana Nusantara","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:58:12"]},{"email":"182.5.244.23","password":"ASN info tidak ditemukan","login":"PT Telekomunikasi Selular Indonesia","ip":"Indonesia","extra":["Sidoarjo","JI","Monday, 2026-3-16 05:58:02"]},{"email":"difadfadli@gmail.com","password":"Hasbi ganteng","login":"Google","ip":"2404:c0:a701:d09e:2c2e:2e8f:e18f:79e7","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Bandung","JB","Monday, 2026-3-16 05:57:56"]},{"email":"dikialkurnianto7@gmail.com","password":"123456789","login":"Google","ip":"157.85.211.113","extra":["ASN info tidak ditemukan","PT XL Axiata Tbk","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:57:54"]},{"email":"lariyahpetung@gmail.com","password":"muhammad  imam","login":"Google","ip":"103.215.187.18","extra":["ASN info tidak ditemukan","PT Jaringan Inti Exadata","Indonesia","South Jakarta","JK","Monday, 2026-3-16 05:57:51"]},{"email":"085835391392","password":"251206","login":"Facebook","ip":"103.133.61.186","extra":["ASN info tidak ditemukan","TLINK","Indonesia","Gedong Tataan","LA","Monday, 2026-3-16 05:57:33"]},{"email":"ahmad080226@gmail.com","password":"Ahmad 1111","login":"Google","ip":"2400:9800:510:44af:c81c:63ff:fe62:3a98","extra":["ASN info tidak ditemukan","Indonesia","Palembang","SS","Monday, 2026-3-16 05:57:17"]},{"email":"narnorehan462@gmail.com","password":"hxzyxz.vskrz.my.id","login":"Google","ip":"117.18.19.148","extra":["ASN info tidak ditemukan","PT ALUCIO","Indonesia","Kertosono","JI","Monday, 2026-3-16 05:56:44"]},{"email":"aji77@gmail.com","password":"aji77777","login":"Google","ip":"103.116.82.146","extra":["ASN info tidak ditemukan","PT SSR Digital Informatika","Indonesia","Indramayu","JB","Monday, 2026-3-16 05:56:43"]},{"email":"marikitamakan25@gmail.com","password":"makansatu","login":"Google","ip":"183.171.101.241","extra":["ASN info tidak ditemukan","Celcom Axiata Berhad","Malaysia","Pasir Mas","03","Monday, 2026-3-16 05:56:10"]},{"email":"masbeyymabey@gmail.com","password":"risna r3y","login":"Google","ip":"103.164.235.95","extra":["ASN info tidak ditemukan","PT Bantani Media Utama","Indonesia","Karangdawa Barat","BT","Monday, 2026-3-16 05:55:53"]},{"email":"103.164.235.95","password":"ASN info tidak ditemukan","login":"PT Bantani Media Utama","ip":"Indonesia","extra":["Karangdawa Barat","BT","Monday, 2026-3-16 05:54:40"]},{"email":"hami49217@gmail.com","password":"ilhamm ham","login":"Google","ip":"114.5.213.207","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Monday, 2026-3-16 05:53:51"]},{"email":"fajrihasibuan00@gmail.com","password":"fajrihasobuan","login":"Google","ip":"202.67.44.8","extra":["ASN info tidak ditemukan","PT Hutchison 3 Indonesia","Indonesia","Pekanbaru","RI","Monday, 2026-3-16 05:52:41"]},{"email":"7745407161","password":"anas suji","login":"Google","ip":"114.122.29.51","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 05:52:01"]},{"email":"Yuyub@gmail.com","password":"yuyub70","login":"Google","ip":"2404:c0:9a2a:732:1:0:4f2c:ff28","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Malang","JI","Monday, 2026-3-16 05:51:29"]},{"email":"Yuyu @gmail.com","password":"yuyub70","login":"Google","ip":"2404:c0:9a2a:732:1:0:4f2c:ff28","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Malang","JI","Monday, 2026-3-16 05:50:07"]},{"email":"ddanu1347@gmail.com","password":"abilganteng098","login":"Google","ip":"36.65.201.117","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Indonesia","Indonesia","Semarang","JT","Monday, 2026-3-16 05:50:05"]},{"email":"riska02nabihan@gmail.com","password":"123456789","login":"Google","ip":"103.155.156.46","extra":["ASN info tidak ditemukan","Mulkan","Indonesia","Cibatu","JB","Monday, 2026-3-16 05:50:02"]},{"email":"aldyfebriansyah039@gmail.com","password":"alsyfebriansyah077","login":"Google","ip":"2400:9800:2b5:2d88:189d:2522:99d:6952","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Monday, 2026-3-16 05:49:37"]},{"email":"aqilaandin9@gmail.com","password":"aqiladanumi","login":"Google","ip":"160.19.227.252","extra":["ASN info tidak ditemukan","PT. Cemerlang Multimedia","Indonesia","Bandung","JB","Monday, 2026-3-16 05:49:22"]},{"email":"ermantino@gmail.com","password":"alayubimyson","login":"Google","ip":"2404:c0:9a2a:732:1:0:4f2c:ff28","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Malang","JI","Monday, 2026-3-16 05:49:08"]},{"email":"36.80.198.46","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Aimas","PD","Monday, 2026-3-16 05:49:02"]},{"email":"zakirganteng327@gmail.com","password":"LU_BOT22","login":"Google","ip":"2001:448a:2003:2a23:2480:b0eb:9c02:2168","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:48:48"]},{"email":"alpincurut123@gmail.com","password":"TAMIM123","login":"Google","ip":"114.5.218.56","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jatiluhur","JB","Monday, 2026-3-16 05:48:34"]},{"email":"adrimiswandif@gmail.com","password":"FAIDILTOKEP","login":"Google","ip":"36.80.198.46","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Aimas","PD","Monday, 2026-3-16 05:47:30"]},{"email":"ahmadmuzajad@gmail.com","password":"123456789","login":"Google","ip":"2400:9800:2d6:21e:9884:8369:dc38:4459","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Monday, 2026-3-16 05:46:36"]},{"email":"rafa2023acehh@gmail.com","password":"PUTRI ALIA","login":"Google","ip":"182.9.161.214","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Banda Aceh","AC","Monday, 2026-3-16 05:46:19"]},{"email":"mohalvin615@gmail.com","password":"alvin gannteng","login":"Google","ip":"157.85.220.9","extra":["ASN info tidak ditemukan","XLNET","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:46:06"]},{"email":"2402:8780:102a:287:245b:e12b:ffea:c99d","password":"ASN info tidak ditemukan","login":"MYREPUBLIC","ip":"Indonesia","extra":["Purwakarta","JB","Monday, 2026-3-16 05:46:00"]},{"email":"raffir14958775@gmail.com","password":"kroco#123","login":"Google","ip":"114.10.40.160","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Medan","SU","Monday, 2026-3-16 05:46:01"]},{"email":"180.242.70.121","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Jakarta","JK","Monday, 2026-3-16 05:45:29"]},{"email":"2402:8780:102a:287:245b:e12b:ffea:c99d","password":"ASN info tidak ditemukan","login":"MYREPUBLIC","ip":"Indonesia","extra":["Purwakarta","JB","Monday, 2026-3-16 05:45:05"]},{"email":"herlansusanto305@gmail.com","password":"SAYA MAU HP","login":"Google","ip":"182.9.161.214","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Banda Aceh","AC","Monday, 2026-3-16 05:44:49"]},{"email":"rezaelsa269@gmail.com","password":"reza elsa","login":"Facebook","ip":"110.136.144.90","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Sukabumi","JB","Monday, 2026-3-16 05:44:28"]},{"email":"N4597362@gmail.com","password":"hafizz","login":"Google","ip":"114.122.40.249","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 05:44:27"]},{"email":"2405:8180:c01:2ef3:fc12:9a51:41d4:53ac","password":"ASN info tidak ditemukan","login":"Indonesia Network Information Center","ip":"Indonesia","extra":["Medan","SU","Monday, 2026-3-16 05:44:23"]},{"email":"syahadats28@gmail.com","password":"TJAH TERATE22","login":"Google","ip":"103.82.246.19","extra":["ASN info tidak ditemukan","PT Master Star Network","Indonesia","Tulangan Utara","JI","Monday, 2026-3-16 05:43:10"]},{"email":"yy22072007@gmail.com","password":"bzfxysbccjx","login":"Google","ip":"180.245.28.177","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Indramayu","JB","Monday, 2026-3-16 05:43:07"]},{"email":"rasyabotak@gmail.com","password":"lapadil","login":"Google","ip":"125.162.214.148","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Monday, 2026-3-16 05:43:01"]},{"email":"Zubaidahtoha02@gmail.com","password":"yudafaki37","login":"Google","ip":"182.8.65.73","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:42:49"]},{"email":"firmansyahverno@gmail.com","password":"rafaganteng","login":"Google","ip":"2001:448a:5142:40da:bd95:f4c4:b9f5:f560","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:42:42"]},{"email":"haikalfatta256@gmail.com","password":"haikalsigma","login":"Google","ip":"157.66.170.164","extra":["ASN info tidak ditemukan","PT Runnet Media Utama","Indonesia","Bekasi","JB","Monday, 2026-3-16 05:42:33"]},{"email":"ahmadmulyana62662@gmail.com","password":"yana12345","login":"Google","ip":"2402:8780:102a:287:245b:e12b:ffea:c99d","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Purwakarta","JB","Monday, 2026-3-16 05:41:58"]},{"email":"180.245.28.177","password":"ASN info tidak ditemukan","login":"Telekomunikasi Indonesia","ip":"Indonesia","extra":["Indramayu","JB","Monday, 2026-3-16 05:41:03"]},{"email":"alkhairathtpq@gmail.com","password":"9597501650","login":"Google","ip":"223.255.224.99","extra":["ASN info tidak ditemukan","PT Hutchison CP Telecommunications","Indonesia","Batam","KR","Monday, 2026-3-16 05:40:58"]},{"email":"Tobatoyy@gmail.com","password":"ieieje","login":"Google","ip":"103.67.47.64","extra":["ASN info tidak ditemukan","PT JARINGANKU SARANA NUSANTARA","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:40:15"]},{"email":"rasyid31abdullah@gmail.com","password":"REHAN134","login":"Google","ip":"202.154.184.226","extra":["ASN info tidak ditemukan","Indonesia Network Information Center","Indonesia","Batam","RI","Monday, 2026-3-16 05:39:18"]},{"email":"kur92205@gmail.com","password":"12345678","login":"Google","ip":"103.4.77.146","extra":["ASN info tidak ditemukan","PT Khazanah Net Indonesia","Indonesia","Parung","JB","Monday, 2026-3-16 05:37:58"]},{"email":"rizqifdlh50@gmail.com","password":"encicomel2509","login":"Google","ip":"157.85.211.145","extra":["ASN info tidak ditemukan","PT XL Axiata Tbk","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:37:03"]},{"email":"mmusdalifah013@gmail.com","password":"majene123456","login":"Google","ip":"180.251.150.236","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Monday, 2026-3-16 05:35:24"]},{"email":"rjulfiyan@gmail.com","password":"Repan123.","login":"Google","ip":"114.124.172.252","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:34:57"]},{"email":"sajalahrifki956@gmail.com","password":"hsjehe","login":"Google","ip":"180.244.26.205","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Depok","JB","Monday, 2026-3-16 05:33:05"]},{"email":"kudapeot724@gmail.com","password":"RIZAL.JR","login":"Google","ip":"2402:5680:930b:c0d9::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 05:32:23"]},{"email":"sahirmanhatika@gmail.com","password":"sqhirmanhatika@gmail.com","login":"Google","ip":"140.213.217.83","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Makassar","SN","Monday, 2026-3-16 05:32:04"]},{"email":"barakahachmad@gmail.com","password":"rakalita","login":"Google","ip":"103.172.71.105","extra":["ASN info tidak ditemukan","AZNET","Indonesia","Karawang","JB","Monday, 2026-3-16 05:30:46"]},{"email":"durohimohim840@gmail.com","password":"6788","login":"Google","ip":"140.213.167.104","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Semarang","JT","Monday, 2026-3-16 05:28:47"]},{"email":"dangda507@gmail.com","password":"dede.123","login":"Google","ip":"2001:448a:1150:21b:8d3d:65a1:3f2c:7ea1","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Kotabumi","LA","Monday, 2026-3-16 05:28:29"]},{"email":"agungcoolplus49@gmail.com","password":"agung aditiya12","login":"Google","ip":"180.246.196.39","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Wanaherang","JB","Monday, 2026-3-16 05:28:09"]},{"email":"musdalifah013@gmail.com","password":"majene123456","login":"Google","ip":"180.251.150.236","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Makassar","SN","Monday, 2026-3-16 05:26:36"]},{"email":"dambriilahi@gmail.com","password":"ginafebriana","login":"Google","ip":"103.76.151.218","extra":["ASN info tidak ditemukan","PT. Java Digital Nusantara","Indonesia","Ponorogo","JI","Monday, 2026-3-16 05:26:33"]},{"email":"s21086736@gmail.com","password":"LinedClamp15778","login":"Google","ip":"201.151.113.18","extra":["ASN info tidak ditemukan","Alestra, S. de R.L. de C.V.","Mexico","La Desembocada","JAL","Monday, 2026-3-16 05:26:29"]},{"email":"wahyufurnama51@gmail.com","password":"alipbokep11","login":"Google","ip":"103.191.165.232","extra":["ASN info tidak ditemukan","PT Sakti Wijaya Network","Indonesia","Subang","JB","Monday, 2026-3-16 05:26:25"]},{"email":"mhoki8786@gmail.com","password":"ffburik5","login":"Google","ip":"2404:c0:b203:3657:d50:cfbb:858c:9fbe","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:23:42"]},{"email":"6283829755361","password":"123456","login":"Google","ip":"140.213.0.32","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:22:52"]},{"email":"ekasakha86@gmail.com","password":"1234567890","login":"Google","ip":"165.101.42.120","extra":["ASN info tidak ditemukan","PT Lintas Jaringan Nusantara","Indonesia","Utan","JK","Monday, 2026-3-16 05:22:46"]},{"email":"arnis3497@gmail.com","password":"leogg232013","login":"Google","ip":"140.213.74.4","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Pinrang","SN","Monday, 2026-3-16 05:22:40"]},{"email":"faridawahib4zk4@gmail.com","password":"12345678","login":"Google","ip":"182.8.99.163","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:22:27"]},{"email":"374785","password":"234","login":"Google","ip":"140.213.0.32","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:21:40"]},{"email":"pakdekambali@gmail.com","password":"zaldyzulfi@gmailcom","login":"Google","ip":"103.141.108.177","extra":["ASN info tidak ditemukan","Data Buana Nusantara","Indonesia","Ngoro","JI","Monday, 2026-3-16 05:20:43"]},{"email":"rafarafasyah35@gmail.com","password":"962282490","login":"Google","ip":"2404:c0:6610::e7:c7d1","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Purwokerto","JT","Monday, 2026-3-16 05:19:56"]},{"email":"wiboworio070@gmail.com","password":"rioardy123","login":"Google","ip":"114.10.101.54","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Kedaton","LA","Monday, 2026-3-16 05:19:16"]},{"email":"rendyzaini1988@gmail.com","password":"RENDY012","login":"Google","ip":"182.8.98.216","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:18:49"]},{"email":"diazadiseptian61@gmail.com","password":"diaz1234567zz","login":"Google","ip":"103.190.171.193","extra":["ASN info tidak ditemukan","WMS","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:18:08"]},{"email":"safriadi15062009@gmail.com","password":"safriyadi11111111","login":"Google","ip":"112.215.230.105","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:18:01"]},{"email":"85750691739","password":"56389","login":"Google","ip":"114.10.143.27,168.235.205.32","extra":["ASN info tidak ditemukan","Monday, 2026-3-16 05:17:28"]},{"email":"kaiderpohan@gmail.com","password":"040713","login":"Google","ip":"2400:9800:450:3ad8:1:0:c9f7:ee2f","extra":["ASN info tidak ditemukan","Indonesia","Medan","SU","Monday, 2026-3-16 05:16:55"]},{"email":"metayani885@gmail.com","password":"lopa","login":"Google","ip":"2404:c0:381a:6838:4f4c:c129:eb99:ae58","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Denpasar","BA","Monday, 2026-3-16 05:16:46"]},{"email":"ramlipak84@gmail.com","password":"fadil","login":"Google","ip":"165.101.230.155","extra":["ASN info tidak ditemukan","PT Anugerah Cimanuk Raya","Indonesia","Karangampel","JB","Monday, 2026-3-16 05:16:21"]},{"email":"hafidzroblox2012@gmail.com","password":"hafidzroblox2","login":"Google","ip":"2400:9800:2cf:f642:189d:1efb:7992:4020","extra":["ASN info tidak ditemukan","Indonesia","Bandung","JB","Monday, 2026-3-16 05:16:13"]},{"email":"safriyadi725@gmail.com","password":"safriyadi11111111","login":"Google","ip":"112.215.230.15","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:16:01"]},{"email":"muhammadzzvalen@gmail.com","password":"valenplenger","login":"Google","ip":"103.160.68.139","extra":["ASN info tidak ditemukan","PT Gayatri Lintas Nusantara","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:15:47"]},{"email":"180.246.204.49","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Melati","YO","Monday, 2026-3-16 05:15:40"]},{"email":"081514444221","password":"asepoenalpot","login":"Facebook","ip":"103.166.158.233","extra":["ASN info tidak ditemukan","PT Timor Lintas Nusantara","Indonesia","Pangkalan","BT","Monday, 2026-3-16 05:15:26"]},{"email":"muhammadvalen772@gmail.com","password":"valen2015@","login":"Google","ip":"103.160.68.139","extra":["ASN info tidak ditemukan","PT Gayatri Lintas Nusantara","Indonesia","Surabaya","JI","Monday, 2026-3-16 05:14:59"]},{"email":"123456","password":"alpan","login":"Google","ip":"114.5.217.246","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Bandung","JB","Monday, 2026-3-16 05:13:42"]},{"email":"085217153095","password":"abdul somad123","login":"Google","ip":"182.2.105.154","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Pontianak","KB","Monday, 2026-3-16 05:12:55"]},{"email":"087894631702","password":"55555555","login":"Google","ip":"2001:448a:702d:1aa8:4fc0:d577:c3d3:7675","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Makassar","SN","Monday, 2026-3-16 05:11:30"]},{"email":"ghufranassuja1805@gmail.com","password":"ghufranASSUJA","login":"Google","ip":"2402:8780:1079:3d14:f718:3b1a:73d6:2a0e","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Medan","SU","Monday, 2026-3-16 05:10:55"]},{"email":"galih71361@gmail.com","password":"galih2026","login":"Google","ip":"103.184.66.137","extra":["ASN info tidak ditemukan","PT Siber Tech Indonesia","Indonesia","Sukatani","BT","Monday, 2026-3-16 05:09:14"]},{"email":"103.67.47.64","password":"ASN info tidak ditemukan","login":"PT JARINGANKU SARANA NUSANTARA","ip":"Indonesia","extra":["Jakarta","JK","Monday, 2026-3-16 05:08:58"]},{"email":"nurulluvi550@gmail.com","password":"nurulluvi","login":"Google","ip":"160.20.38.109","extra":["ASN info tidak ditemukan","PT SAMUDRA DIGITAL NETWORK","Indonesia","Indramayu","JB","Monday, 2026-3-16 05:08:40"]},{"email":"wayu18657@gmail.com","password":"12345678910","login":"Google","ip":"182.4.36.5","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Palangkaraya","KT","Monday, 2026-3-16 05:06:47"]},{"email":"ms1084172@gmail.com","password":"123denigabteng","login":"Google","ip":"112.215.235.51","extra":["ASN info tidak ditemukan","XL-AXIATA Tbk GSM","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:06:05"]},{"email":"sailililah81@gmail.com","password":"12345678aj#","login":"Google","ip":"39.194.3.103","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular","Indonesia","Banjarmasin","KS","Monday, 2026-3-16 05:05:57"]},{"email":"alvaromalvaro358@gmail.com","password":"eu9eye9eue","login":"Google","ip":"103.67.47.64","extra":["ASN info tidak ditemukan","PT JARINGANKU SARANA NUSANTARA","Indonesia","Jakarta","JK","Monday, 2026-3-16 05:05:24"]},{"email":"anjarsipalingbaik@gmail.com","password":"anjar4444","login":"Google","ip":"103.162.63.225","extra":["ASN info tidak ditemukan","PT Ring Media Nusantara","Indonesia","Dukuhturi","JT","Monday, 2026-3-16 05:04:18"]},{"email":"2402:8780:1034:352:d91c:6f94:fcce:8ad1","password":"ASN info tidak ditemukan","login":"MYREPUBLIC","ip":"Indonesia","extra":["Adiwerna","JT","Monday, 2026-3-16 05:03:55"]},{"email":"naswaramadhaniaputri@gmail.com","password":"123123","login":"Google","ip":"103.126.119.252","extra":["ASN info tidak ditemukan","PT. Media Tekno Nusantara","Indonesia","Tangerang","BT","Monday, 2026-3-16 05:03:39"]},{"email":"2402:8780:104d:45c1:f531:152c:9be4:85d2","password":"ASN info tidak ditemukan","login":"MYREPUBLIC","ip":"Indonesia","extra":["Kendari","SG","Monday, 2026-3-16 05:03:39"]},{"email":"zaa49808@gmail.com","password":"123456789","login":"Google","ip":"2402:8780:1034:352:d91c:6f94:fcce:8ad1","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Adiwerna","JT","Monday, 2026-3-16 05:03:21"]},{"email":"wwegiaryadi@gmail.com","password":"130393","login":"Google","ip":"2402:5680:818f:a604::1","extra":["ASN info tidak ditemukan","SMARTFREN","Indonesia","Serpong","JB","Monday, 2026-3-16 05:02:09"]},{"email":"0882005751782","password":"paling2882","login":"Google","ip":"113.192.31.84","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Duren Tiga","JK","Monday, 2026-3-16 04:55:24"]},{"email":"85352685002","password":"123456789","login":"Facebook","ip":"2404:c0:2b10::69a:e7e3","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Bandung","JB","Monday, 2026-3-16 04:55:46"]},{"email":"Stoksgopm@gmail.com","password":"harfyaod","login":"Google","ip":"140.213.86.61","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Singkawang","KB","Monday, 2026-3-16 04:55:08"]},{"email":"113.192.31.84","password":"ASN info tidak ditemukan","login":"PT Indo Telemedia Solusi","ip":"Indonesia","extra":["Duren Tiga","JK","Monday, 2026-3-16 04:49:53"]},{"email":"hf6481169@gmail.com","password":"tHNHXeY4MtuPe","login":"Google","ip":"182.1.237.35","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Palembang","SS","Monday, 2026-3-16 04:49:51"]},{"email":"f8658205@gmail.com","password":"asuko36688","login":"Google","ip":"113.192.31.84","extra":["ASN info tidak ditemukan","PT Indo Telemedia Solusi","Indonesia","Duren Tiga","JK","Monday, 2026-3-16 04:48:47"]},{"email":"hasbifaeza254@gmail.com","password":"hasbi stecu rorrr","login":"Google","ip":"180.248.24.88","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Malang","JI","Monday, 2026-3-16 04:48:21"]},{"email":"rojakrazzak@gmail.com","password":"HOUXVII_@com","login":"Google","ip":"140.213.34.40","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:48:18"]},{"email":"jnjprimainfinit7@gmail.com","password":"juanjose16","login":"Google","ip":"110.138.129.184","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Bekasi","JB","Monday, 2026-3-16 04:48:10"]},{"email":"erpanhutasoit5@gmail.com","password":"kotapinang","login":"Google","ip":"2404:c0:9601:b08a:5741:b54e:899d:1a56","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 04:47:59"]},{"email":"10870950","password":"186593766","login":"Facebook","ip":"103.166.90.146","extra":["ASN info tidak ditemukan","PT Regynet Data Solusindo","Indonesia","Cikarang","JB","Monday, 2026-3-16 04:47:00"]},{"email":"ummiardin80@gmail.com","password":"nawfal2014","login":"Google","ip":"114.125.203.213","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Makassar","SN","Monday, 2026-3-16 04:46:24"]},{"email":"hinfinik348@gmail.com","password":"alda1234aaaa","login":"Google","ip":"114.122.15.118","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 04:45:57"]},{"email":"kristianrohadihutasoit@gmail.com","password":"kotaasahan","login":"Google","ip":"2404:c0:9601:b08a:5741:b54e:899d:1a56","extra":["ASN info tidak ditemukan","PT. Telekomunikasi Selular (Telkomsel) Indonesia","Indonesia","Medan","SU","Monday, 2026-3-16 04:45:00"]},{"email":"alpinhariyadi19@gmail.com","password":"alpin 123","login":"Google","ip":"125.164.44.122","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Mataram","NB","Monday, 2026-3-16 04:43:42"]},{"email":"12146","password":"121234","login":"Google","ip":"103.166.90.146","extra":["ASN info tidak ditemukan","PT Regynet Data Solusindo","Indonesia","Cikarang","JB","Monday, 2026-3-16 04:42:41"]},{"email":"mmuhammadyafis@gmail.com","password":"LUPA KATA SANDII","login":"Google","ip":"110.137.41.71","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Bandar Lampung","LA","Monday, 2026-3-16 04:40:15"]},{"email":"Farishaarsyifasyah@gmail.com","password":"akucantik","login":"Google","ip":"2001:448a:7100:2389:e582:cbc6:2c6e:987e","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Sofifi","MU","Monday, 2026-3-16 04:39:46"]},{"email":"xemoxykennardkecebanget@gmail.com","password":"kennard.11","login":"Google","ip":"2001:448a:20a0:69da:7981:1d93:841b:d986","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:39:24"]},{"email":"radityabaru41@gmail.com","password":"Radit12@","login":"Google","ip":"103.155.197.1","extra":["ASN info tidak ditemukan","JEMBATANDATA","Indonesia","Bandung","JB","Monday, 2026-3-16 04:38:51"]},{"email":"82310072024","password":"12","login":"Google","ip":"2001:448a:20a0:69da:7981:1d93:841b:d986","extra":["ASN info tidak ditemukan","Telekomunikasi Indonesia","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:38:47"]},{"email":"081369116209","password":"ileman74","login":"Facebook","ip":"202.65.238.42","extra":["ASN info tidak ditemukan","SpaceX Starlink","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:34:11"]},{"email":"083125622034","password":"rendi123","login":"Facebook","ip":"103.215.60.50","extra":["ASN info tidak ditemukan","PT Uwais Borneo Group","Indonesia","Pontianak","KB","Monday, 2026-3-16 04:32:11"]},{"email":"tolembekaydar@gmail.com","password":"yasina21","login":"Google","ip":"95.56.30.53","extra":["ASN info tidak ditemukan","JSC Kazakhtelecom","Kazakhstan","Almaty","75","Monday, 2026-3-16 04:29:47"]},{"email":"haqqin113@gmail.com","password":"haqqingg124","login":"Google","ip":"114.10.76.229","extra":["ASN info tidak ditemukan","PT. INDOSAT Tbk","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:27:46"]},{"email":"yttaazzjj@gmail.com","password":"nyambekiswonderfull","login":"Google","ip":"103.170.96.71","extra":["ASN info tidak ditemukan","PT. Global Data Akses Persada","Indonesia","Pasuruan","JI","Monday, 2026-3-16 04:27:13"]},{"email":"benaja123@gmail.com","password":"ruben123","login":"Google","ip":"Indonesia","extra":["Pekanbaru","Telekomunikasi Indonesia","2001:448a:1082:8ba7:e141:7a5d:f722:a297"]},{"email":"081563438976","password":"281220","login":"Facebook","ip":"180.246.20.172","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Sukabumi","JB","Monday, 2026-3-16 04:25:19"]},{"email":"Jehanoerzhehasetiawan636@gmail.com","password":"787","login":"Google","ip":"36.75.2.145","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tangerang","BT","Monday, 2026-3-16 04:25:02"]},{"email":"081371169541","password":"ffbetabattlegroun@gmailcom","login":"Google","ip":"103.178.223.115","extra":["ASN info tidak ditemukan","PT Agung Network Solution","Indonesia","Baserah","RI","Monday, 2026-3-16 04:24:42"]},{"email":"jehanoerzhehasetiawan636@gmail.com","password":"787","login":"Google","ip":"36.75.2.145","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tangerang","BT","Monday, 2026-3-16 04:23:46"]},{"email":"fitriciput007@gmail.com","password":"aminahku","login":"Google","ip":"36.71.158.117","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","VILLA PERMATA HIJAU","JB","Monday, 2026-3-16 04:23:19"]},{"email":"fitriciput007@gmail.com","password":"aminahku","login":"Google","ip":"36.71.158.117","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","VILLA PERMATA HIJAU","JB","Monday, 2026-3-16 04:23:19"]},{"email":"hritikjerry60@gmail.com","password":"Hritik Jerry","login":"Google","ip":"180.241.31.205","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Tarakan","KU","Monday, 2026-3-16 04:22:14"]},{"email":"36.75.11.156","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Jakarta","JK","Monday, 2026-3-16 04:22:10"]},{"email":"alfian171219@gmail.com","password":"bombom_imoets","login":"Google","ip":"103.1.51.159","extra":["ASN info tidak ditemukan","PT. PRATAMA HASTA UTAMA SOLUSINDO","Indonesia","Bondowoso","JI","Monday, 2026-3-16 04:21:39"]},{"email":"botaklicin122333@gmail.com","password":"37Qwbq_Y*XHD#$Q","login":"Google","ip":"36.75.11.156","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Jakarta","JK","Monday, 2026-3-16 04:20:47"]},{"email":"vanzzyx999@gmail.com","password":"danipantas3","login":"Google","ip":"180.247.34.121","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Surabaya","JI","Monday, 2026-3-16 04:19:45"]},{"email":"irmaantogia23@gmail.com","password":"irma123","login":"Facebook","ip":"36.85.225.148","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Manado","SA","Monday, 2026-3-16 04:19:20"]},{"email":"muhammadafrizal535@gmail.com","password":"AFRIZAL","login":"Google","ip":"140.213.159.72","extra":["ASN info tidak ditemukan","PT Excelcomindo Pratama","Indonesia","Banjar Badung","BA","Monday, 2026-3-16 04:18:42"]},{"email":"10112014.adhim@gmail.com","password":"eF528VGjC@86SBN","login":"Google","ip":"2402:8780:1019:7eda:f8e7:d8a:5a45:ea0","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Jombang","JI","Monday, 2026-3-16 04:17:11"]},{"email":"180.242.236.16","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Pontianak","KB","Monday, 2026-3-16 04:16:24"]},{"email":"125.163.64.66","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Mataram","NB","Monday, 2026-3-16 04:12:36"]},{"email":"125.163.64.66","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Mataram","NB","Monday, 2026-3-16 04:11:59"]},{"email":"125.163.64.66","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Mataram","NB","Monday, 2026-3-16 04:11:46"]},{"email":"125.163.64.66","password":"ASN info tidak ditemukan","login":"PT. TELKOM INDONESIA","ip":"Indonesia","extra":["Mataram","NB","Monday, 2026-3-16 04:10:55"]},{"email":"gokgokgokgok196@gmail.com","password":"GOKGOKGOK321","login":"Google","ip":"125.163.64.66","extra":["ASN info tidak ditemukan","PT. TELKOM INDONESIA","Indonesia","Mataram","NB","Monday, 2026-3-16 04:09:31"]},{"email":"dafasatya03@gmail.com","password":"PASTEX214","login":"Google","ip":"2400:9800:363:a42a:204f:9dff:fe72:2528","extra":["ASN info tidak ditemukan","Indonesia","Ciampea","JB","Monday, 2026-3-16 04:07:05"]},{"email":"ripandir524@gmail.com","password":"ipan12345678","login":"Google","ip":"114.122.212.226","extra":["ASN info tidak ditemukan","PT Telekomunikasi Selular Indonesia","Indonesia","Martapura","KS","Monday, 2026-3-16 04:05:45"]},{"email":"riplayrisky26@gmail.com","password":"katak beracun","login":"Google","ip":"2402:8780:1045:1747:6307:e4db:e793:2d43","extra":["ASN info tidak ditemukan","MYREPUBLIC","Indonesia","Dukuhturi","JT","Monday, 2026-3-16 04:05:26"]}];
let saved = JSON.parse(sessionStorage.getItem("savedMail") || "[]");
let current = null;
let currentMenu = "inbox";

// ELEMENT
let count = data.length - saved.length;
const sidebar   = document.getElementById("sidebar");
const content   = document.getElementById("content");
const popupEmail = document.getElementById("popupEmail");
const tblDetail = document.getElementById("tblDetail");
const overlay = document.getElementById("overlay");

function toggleSidebar(){
    sidebar.classList.toggle("visible");
    overlay.classList.toggle("show");
}

function closeSidebar(){
    sidebar.classList.remove("visible");
    overlay.classList.remove("show");
}

function closePopup(){
    popupEmail.style.display = "none";
}

function refreshInbox(){
    location.reload();
}

/* AUTO CLOSE JIKA KLIK LUAR POPUP */
popupEmail.addEventListener("click", function(e){
    if(e.target === popupEmail){
        closePopup();
    }
});

// HITUNG JUMLAH
function updateCount(){
    if (count <= 99) {
        document.getElementById("inboxCount").innerText = count;
    }
    document.getElementById("saveCount").innerText = saved.length;
}

// FORMAT JAM
function formatJam(){
    let d = new Date();
    let h = String(d.getHours()).padStart(2,"0");
    let m = String(d.getMinutes()).padStart(2,"0");
    return h + "." + m;
}

// SIMPAN EMAIL
function saveMail(){
    if(current === null) return;

    if(!saved.includes(current)){
        saved.push(current);
        sessionStorage.setItem("savedMail", JSON.stringify(saved));
    }

    popupEmail.style.display = "none";

    if(currentMenu === "saved"){
        showSaved(document.querySelector(".menu-item.active"));
    }else{
        showInbox(document.querySelector(".menu-item.active"));
    }
}

// KOTAK MASUK
function showInbox(el){
    currentMenu = "inbox";
    setActive(el);

    content.innerHTML = `
<div class="title">
    <div class="icon mail"></div>
    <span>Kotak Masuk</span>
</div>
`;

    data.forEach((d,i)=>{
        if(saved.includes(i)) return;

        content.innerHTML += `
<div class="mail-item" onclick="openMail(${i})">
    <div class="avatar"></div>

    <div class="left multi">
        <div class="subject">WEB GANZZ NESIA</div>
        <div class="subtitle">Result | Punya Si ${d.email}</div>
        <div class="preview">Info Login ${d.login} Email ${d.email}</div>
    </div>

    <div class="right">${formatJam()}</div>
</div>`;
    });

    updateCount();
}

// KOTAK SIMPAN
function showSaved(el){
    currentMenu = "saved";
    setActive(el);

    content.innerHTML = `
<div class="title">
    <div class="icon save"><span></span></div>
    <span>Kotak Simpan</span>
</div>
`;

    if(saved.length === 0){
        content.innerHTML += "<p>Tidak ada data tersimpan</p>";
        updateCount();
        return;
    }

    saved.forEach(i=>{
        let d = data[i];

        content.innerHTML += `
<div class="mail-item" onclick="openMail(${i})">
    <div class="avatar"></div>

    <div class="left multi">
        <div class="subject">WEB GANZZ NESIA</div>
        <div class="subtitle">Result | Punya Si ${d.email}</div>
        <div class="preview">Info Login ${d.login} Email ${d.email}</div>
    </div>

    <div class="right">Saved</div>
</div>`;
    });

    updateCount();
}

// BUKA DETAIL
function openMail(i){
    let d = data[i];
    tblDetail.innerHTML = `
<tr>
<th colspan="3" style="padding:0;border:none">
<div class="detail-header">
<button class="btn-save" onclick="saveMail()">Simpan</button>
<div class="header-title">Info Login ${d.login}</div>
<button class="close-x" onclick="closePopup()">X</button>
</div>
</th>
</tr>
<tr><td><b>Email</b></td><td colspan="2">${d.email}</td></tr>
<tr><td><b>Password</b></td><td colspan="2">${d.password}</td></tr>
<tr><td><b>Login</b></td><td colspan="2">${d.login}</td></tr>
<tr><td><b>IP</b></td><td colspan="2">${d.ip}</td></tr>
${
    d.extra?.filter(x=>x.trim()!=='').map((e,j)=>`<tr><td><b>Info</b></td><td colspan="2">${e}</td></tr>`).join('')
}
<tr>
<th colspan="3" style="text-align:center;padding:10px;background:#0f172a;color:#fff;font-size:12px;border:none">
ORDER KEY 085182792979
</th>
</tr>
`;
    popupEmail.style.display = "flex";
}

// MENU AKTIF
function setActive(el){
    document.querySelectorAll(".menu-list li")
        .forEach(x=>x.classList.remove("active"));
    if(el) el.classList.add("active");
    closeSidebar();
}

// LINK
function openLink(u){
    window.location.href = u;
}

// LOAD DEFAULT MASUK
showInbox(document.querySelector(".menu-item"));

// TIMER
let end = <?php echo $_SESSION['expire']; ?> * 1000;

function updateTimer() {
    let s = Math.floor((end - Date.now()) / 1000);

    if(s <= 0){
        location.href = "index.php?expired";
        return;
    }

    let hour  = Math.floor(s / 3600);
    let min   = Math.floor((s % 3600) / 60);
    let sec   = s % 60;

    let text = "";

    if(hour > 0){
        text = hour + " JAM " + min + " MENIT";  // <--- ganti h→J, m→M
    }
    else if(min > 0){
        text = min + " MENIT " + sec + " DETIK ";   // <--- ganti m→M, s→S
    }
    else{
        text = sec + " DETIK ";                // <--- s→S
    }

    document.getElementById("timer").innerText = text;
}

updateTimer();
setInterval(updateTimer, 1000);
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"21c7c62f488741ad8ca4cf9f64f7dffb","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>