<?php
session_start();

$key = $_POST['user_key'];

if($key == $_SESSION['key']){

if(time() < $_SESSION['expire']){

$_SESSION['login'] = true;

header("Location: utama.php");
exit;

}else{
echo "KEY EXPIRED";
}

}else{
echo "KEY SALAH";
}
?>